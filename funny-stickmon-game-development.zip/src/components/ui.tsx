import { useEffect, useState, type ReactNode } from 'react';
import { TYPE_COLORS, TYPE_EMOJI, type StickType } from '../data/types';
import { SPECIES } from '../data/stickmon';
import { MOVES } from '../data/moves';
import { type MonInstance, xpForLevel } from '../game/logic';
import StickmonSprite from './StickmonSprite';

export function TypeBadge({ type, small }: { type: StickType; small?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-bold text-white ${TYPE_COLORS[type]} ${small ? 'px-1.5 py-0 text-[10px]' : 'px-2 py-0.5 text-xs'}`}>
      {TYPE_EMOJI[type]} {type}
    </span>
  );
}

export function HpBar({ hp, maxHp, showNum, height = 'h-3' }: { hp: number; maxHp: number; showNum?: boolean; height?: string }) {
  const pct = Math.max(0, Math.min(100, (hp / maxHp) * 100));
  const color = pct > 50 ? 'bg-green-500' : pct > 20 ? 'bg-yellow-400' : 'bg-red-500';
  return (
    <div>
      <div className={`w-full ${height} rounded-full border-2 border-gray-800 bg-gray-200 overflow-hidden`}>
        <div className={`${height} ${color} transition-all duration-500 ease-out`} style={{ width: `${pct}%` }} />
      </div>
      {showNum && <div className="text-right text-xs font-bold text-gray-700">{Math.max(0, hp)} / {maxHp}</div>}
    </div>
  );
}

export function XpBar({ mon }: { mon: MonInstance }) {
  const cur = xpForLevel(mon.level);
  const next = xpForLevel(mon.level + 1);
  const pct = Math.max(0, Math.min(100, ((mon.xp - cur) / (next - cur)) * 100));
  return (
    <div className="w-full h-1.5 rounded-full bg-gray-300 overflow-hidden border border-gray-800">
      <div className="h-full bg-sky-500 transition-all duration-500" style={{ width: `${pct}%` }} />
    </div>
  );
}

export function useTypewriter(text: string, speed = 18) {
  const [shown, setShown] = useState('');
  const [done, setDone] = useState(false);
  useEffect(() => {
    setShown('');
    setDone(false);
    let i = 0;
    const id = setInterval(() => {
      i++;
      setShown(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(id);
        setDone(true);
      }
    }, speed);
    return () => clearInterval(id);
  }, [text, speed]);
  return { shown, done, skip: () => { setShown(text); setDone(true); } };
}

export function DialogBox({ text, onNext, hint = 'Bấm để tiếp ▶', speaker }: { text: string; onNext?: () => void; hint?: string; speaker?: string }) {
  const { shown, done, skip } = useTypewriter(text);
  return (
    <div
      className="paper sketch-border relative w-full cursor-pointer select-none p-4 pr-6 text-lg leading-snug text-gray-900 min-h-[92px]"
      onClick={() => { if (!done) skip(); else if (onNext) onNext(); }}
    >
      {speaker && <div className="absolute -top-4 left-4 bg-yellow-300 sketch-border-sm px-2 text-sm font-bold">{speaker}</div>}
      <span>{shown}</span>
      {done && onNext && <span className="absolute bottom-1 right-3 text-xs text-gray-500 anim-blink">{hint}</span>}
    </div>
  );
}

export function Button({ children, onClick, disabled, className = '', color = 'bg-white' }: { children: ReactNode; onClick?: () => void; disabled?: boolean; className?: string; color?: string }) {
  return (
    <button onClick={onClick} disabled={disabled} className={`sketch-btn ${color} px-3 py-2 font-bold text-gray-900 ${className}`}>
      {children}
    </button>
  );
}

export function MonCard({ mon, onClick, selected, action, compact }: { mon: MonInstance; onClick?: () => void; selected?: boolean; action?: string; compact?: boolean }) {
  const sp = SPECIES[mon.speciesId];
  const fainted = mon.hp <= 0;
  return (
    <div
      onClick={onClick}
      className={`paper sketch-border-sm flex items-center gap-3 p-2 ${onClick ? 'cursor-pointer hover:bg-yellow-50' : ''} ${selected ? 'ring-4 ring-yellow-400' : ''} ${fainted ? 'opacity-60 grayscale' : ''}`}
    >
      <StickmonSprite speciesId={mon.speciesId} size={compact ? 44 : 60} fainted={fainted} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="font-bold truncate">{sp.name}</span>
          <span className="text-xs font-bold text-gray-600">Lv.{mon.level}</span>
        </div>
        <div className="flex items-center gap-1 mb-1"><TypeBadge type={sp.type} small />{fainted && <span className="text-[10px] font-bold text-red-600">NGẤT</span>}</div>
        <HpBar hp={mon.hp} maxHp={mon.maxHp} height="h-2" />
        <div className="text-[11px] text-right text-gray-600">{Math.max(0, mon.hp)}/{mon.maxHp}</div>
        {!compact && (
          <div className="flex flex-wrap gap-1 mt-1">
            {mon.moves.map((m) => <span key={m} className="text-[10px] bg-gray-100 border border-gray-400 rounded px-1">{MOVES[m].name}</span>)}
          </div>
        )}
      </div>
      {action && <span className="text-xs font-bold bg-yellow-300 px-2 py-1 sketch-border-sm">{action}</span>}
    </div>
  );
}
