import { useCallback, useEffect, useRef, useState } from 'react';
import { SPECIES } from '../data/stickmon';
import { MOVES } from '../data/moves';
import { ITEMS, type ItemId } from '../data/items';
import { effectiveness } from '../data/types';
import { type BattleState, type Step, type Anim, type PlayerAction, runTurn, runForceSwitch } from '../game/battle';
import { pick } from '../game/logic';
import StickmonSprite from './StickmonSprite';
import { HpBar, XpBar, TypeBadge, DialogBox, Button, MonCard } from './ui';

interface Props {
  initial: BattleState;
  bg: string;
  trainerEmoji?: string;
  onEnd: (final: BattleState) => void;
}

type Phase = 'steps' | 'menu' | 'moves' | 'bag' | 'bagTarget' | 'party' | 'forceSwitch' | 'end';

const menuLines = ['{n} sẽ làm gì đây?', 'Lệnh cho {n} đi sếp!', '{n} đang chờ chỉ đạo. Nhanh lên!', '{n}: "Sao? Đánh không?"', 'Nghĩ kỹ đi... {n} tin bạn (hơi hơi).'];
const wildIntro = ['Một {n} hoang dã xuất hiện! Nó nhìn bạn với ánh mắt hình viên đạn.', '{n} hoang dã nhảy ra từ bụi rậm! Bụi rậm bị thương nhẹ.', 'Ối! {n} hoang dã! Nó vừa ăn xong nên đang khó chịu.', '{n} hoang dã xuất hiện và hét: "ĐẤT CỦA TAO!"'];

function buildIntro(initial: BattleState): Step[] {
  const intro: Step[] = [];
  const fn = SPECIES[initial.enemyParty[initial.enemyIdx].speciesId].name;
  if (initial.isTrainer) {
    intro.push({ text: `${initial.trainerName} muốn đấu!`, state: initial });
    intro.push({ text: `${initial.trainerName} tung ra ${fn}!`, state: initial, anim: { who: 'enemy', kind: 'enter' } });
  } else {
    intro.push({ text: pick(wildIntro).replace('{n}', fn), state: initial, anim: { who: 'enemy', kind: 'enter' } });
  }
  intro.push({ text: `Lên đi ${SPECIES[initial.party[initial.activeIdx].speciesId].name}! Cố lên nhé!`, state: initial, anim: { who: 'player', kind: 'enter' } });
  return intro;
}

export default function Battle({ initial, bg, trainerEmoji, onEnd }: Props) {
  const [bs, setBs] = useState<BattleState>(initial);
  const [phase, setPhase] = useState<Phase>('steps');
  const [steps, setSteps] = useState<Step[]>(() => buildIntro(initial));
  const [stepIdx, setStepIdx] = useState(0);
  const [text, setText] = useState('');
  const [anim, setAnim] = useState<(Anim & { key: number }) | null>(null);
  const [pendingItem, setPendingItem] = useState<ItemId | null>(null);
  const [menuLine] = useState(pick(menuLines));
  const [shake, setShake] = useState(0);
  const animKey = useRef(0);

  const me = bs.party[bs.activeIdx];
  const foe = bs.enemyParty[bs.enemyIdx];
  const meSp = SPECIES[me.speciesId];
  const foeSp = SPECIES[foe.speciesId];

  // play the current step
  useEffect(() => {
    if (phase !== 'steps') return;
    const st = steps[stepIdx];
    if (!st) {
      // finished
      if (bs.outcome) setPhase('end');
      else if (bs.needSwitch) setPhase('forceSwitch');
      else setPhase('menu');
      return;
    }
    setText(st.text);
    setBs(st.state);
    if (st.anim) {
      animKey.current += 1;
      setAnim({ ...st.anim, key: animKey.current });
      if (st.anim.kind === 'hit' && st.anim.who === 'player') setShake((s) => s + 1);
    } else {
      setAnim(null);
    }
    const delay = Math.min(3200, 700 + st.text.length * 22);
    const id = setTimeout(() => setStepIdx((i) => i + 1), delay);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, steps, stepIdx]);

  const advance = useCallback(() => {
    if (phase === 'steps') setStepIdx((i) => i + 1);
  }, [phase]);

  const doAction = (a: PlayerAction) => {
    const s = runTurn(bs, a);
    setSteps(s);
    setStepIdx(0);
    setPhase('steps');
  };

  const doForceSwitch = (idx: number) => {
    const s = runForceSwitch(bs, idx);
    setSteps(s);
    setStepIdx(0);
    setPhase('steps');
  };

  const spriteAnim = (who: 'player' | 'enemy') => {
    if (!anim || anim.who !== who) return who === 'player' ? 'anim-bob' : 'anim-bob';
    switch (anim.kind) {
      case 'attack': return who === 'player' ? 'anim-attack-right' : 'anim-attack-left';
      case 'hit': return 'anim-hit';
      case 'faint': return 'anim-faint';
      case 'enter': return 'anim-enter';
      case 'heal': return 'anim-heal';
      case 'levelup': return 'anim-levelup';
      default: return '';
    }
  };

  const foeInBall = anim?.who === 'enemy' && anim.kind === 'ball';
  const foeFainted = foe.hp <= 0;
  const meFainted = me.hp <= 0;

  const menuText = (() => {
    switch (phase) {
      case 'menu': return menuLine.replace('{n}', meSp.name);
      case 'moves': return 'Chọn chiêu nào? Chọn khôn vào.';
      case 'bag': return 'Lục túi... có gì ăn được không?';
      case 'bagTarget': return `Dùng ${pendingItem ? ITEMS[pendingItem].name : ''} cho ai?`;
      case 'party': return 'Đổi con nào ra? (Con hiện tại sẽ giận đấy)';
      case 'forceSwitch': return 'Chọn Stickmon tiếp theo! Nhanh lên, đối thủ đang ngáp!';
      case 'end':
        if (bs.outcome === 'win') return bs.isTrainer ? `Bạn đã hạ gục ${bs.trainerName}! Nhận ${bs.moneyBonus > 0 ? bs.moneyBonus : ''} Xu thưởng!`.replace('  ', ' ') : 'Bạn thắng! Con que hoang dã đã học được bài học.';
        if (bs.outcome === 'lose') return 'Bạn thua rồi... Bạn chạy về Trung Tâm Stickmon trong nước mắt.';
        if (bs.outcome === 'caught') return `Tuyệt vời! ${SPECIES[bs.caught!.speciesId].name} đã là của bạn!`;
        return 'Chạy thoát rồi! Phù...';
      default: return text;
    }
  })();

  return (
    <div className="flex flex-col h-full">
      {/* ARENA */}
      <div key={`shake-${shake}`} className={`relative flex-1 min-h-[300px] sm:min-h-[340px] bg-gradient-to-b ${bg} overflow-hidden ${shake ? 'anim-shake' : ''}`}>
        {/* ground ellipses */}
        <div className="absolute right-[6%] top-[38%] w-44 h-10 rounded-[50%] bg-black/10" />
        <div className="absolute left-[6%] bottom-[4%] w-52 h-12 rounded-[50%] bg-black/10" />

        {/* enemy info */}
        <div className="absolute left-2 top-2 sm:left-4 sm:top-4 paper sketch-border-sm p-2 w-52 sm:w-60 anim-pop">
          <div className="flex justify-between items-center">
            <span className="font-bold text-sm truncate">{foeSp.name}</span>
            <span className="text-xs font-bold">Lv.{foe.level}</span>
          </div>
          <div className="mb-1"><TypeBadge type={foeSp.type} small /></div>
          <HpBar hp={foe.hp} maxHp={foe.maxHp} />
          {bs.isTrainer && (
            <div className="flex gap-1 mt-1">
              {bs.enemyParty.map((m, i) => <span key={i} className={`w-3 h-3 rounded-full border border-gray-800 ${m.hp > 0 ? 'bg-red-500' : 'bg-gray-400'}`} />)}
            </div>
          )}
          {(foe.atkStage !== 0 || foe.defStage !== 0) && (
            <div className="text-[10px] text-gray-600">ATK {foe.atkStage >= 0 ? '+' : ''}{foe.atkStage} / DEF {foe.defStage >= 0 ? '+' : ''}{foe.defStage}</div>
          )}
        </div>

        {/* enemy sprite */}
        <div className="absolute right-[8%] top-[6%] sm:right-[12%] flex flex-col items-center">
          {trainerEmoji && bs.isTrainer && <div className="absolute -right-12 -top-2 text-4xl opacity-80 anim-wiggle">{trainerEmoji}</div>}
          {foeInBall ? (
            <div key={anim?.key} className={`text-6xl ${text.startsWith('Bạn ném') ? 'anim-ball' : text.startsWith('Lắc') ? 'anim-wobble' : ''} mt-16`}>🥎</div>
          ) : foeFainted && anim?.kind !== 'faint' ? null : (
            <div key={`${foe.uid}-${anim?.who === 'enemy' ? anim.key : 'idle'}`} className={spriteAnim('enemy')}>
              <StickmonSprite speciesId={foe.speciesId} size={130} facing="left" />
            </div>
          )}
        </div>

        {/* player sprite */}
        <div className="absolute left-[6%] bottom-[2%] sm:left-[10%]">
          <div key={`${me.uid}-${anim?.who === 'player' ? anim.key : 'idle'}`} className={spriteAnim('player')}>
            <StickmonSprite speciesId={me.speciesId} size={160} facing="right" fainted={meFainted && !(anim?.kind === 'faint')} />
          </div>
        </div>

        {/* player info */}
        <div className="absolute right-2 bottom-2 sm:right-4 sm:bottom-4 paper sketch-border-sm p-2 w-56 sm:w-64 anim-pop">
          <div className="flex justify-between items-center">
            <span className="font-bold text-sm truncate">{meSp.name}</span>
            <span className="text-xs font-bold">Lv.{me.level}</span>
          </div>
          <div className="mb-1"><TypeBadge type={meSp.type} small /></div>
          <HpBar hp={me.hp} maxHp={me.maxHp} showNum />
          <XpBar mon={me} />
          <div className="flex gap-1 mt-1">
            {bs.party.map((m, i) => <span key={i} className={`w-3 h-3 rounded-full border border-gray-800 ${m.hp > 0 ? (i === bs.activeIdx ? 'bg-yellow-400' : 'bg-green-500') : 'bg-gray-400'}`} />)}
          </div>
          {(me.atkStage !== 0 || me.defStage !== 0) && (
            <div className="text-[10px] text-gray-600">ATK {me.atkStage >= 0 ? '+' : ''}{me.atkStage} / DEF {me.defStage >= 0 ? '+' : ''}{me.defStage}</div>
          )}
        </div>
      </div>

      {/* CONTROL PANEL */}
      <div className="bg-gray-800 p-3 flex flex-col sm:flex-row gap-3">
        <div className="flex-1 min-w-0">
          <DialogBox text={menuText} onNext={phase === 'steps' ? advance : undefined} hint="Bấm để nhanh ▶" />
        </div>
        <div className="sm:w-80 shrink-0">
          {phase === 'menu' && (
            <div className="grid grid-cols-2 gap-2 h-full">
              <Button color="bg-red-400" onClick={() => setPhase('moves')} className="text-lg">⚔️ ĐÁNH</Button>
              <Button color="bg-amber-300" onClick={() => setPhase('bag')} className="text-lg">🎒 TÚI</Button>
              <Button color="bg-green-400" onClick={() => setPhase('party')} className="text-lg">🔄 ĐỔI</Button>
              <Button color="bg-sky-300" onClick={() => doAction({ type: 'run' })} className="text-lg">🏃 CHẠY</Button>
            </div>
          )}
          {phase === 'moves' && (
            <div className="grid grid-cols-2 gap-2">
              {me.moves.map((mid) => {
                const mv = MOVES[mid];
                const eff = mv.power > 0 ? effectiveness(mv.type, foeSp.type) : 1;
                return (
                  <button key={mid} onClick={() => doAction({ type: 'move', moveId: mid })} className="sketch-btn bg-white p-2 text-left" title={mv.desc}>
                    <div className="font-bold text-sm leading-tight">{mv.name}</div>
                    <div className="flex items-center justify-between mt-1">
                      <TypeBadge type={mv.type} small />
                      <span className="text-[10px] text-gray-600">{mv.power > 0 ? `${mv.power}💥` : 'Hỗ trợ'} {mv.accuracy}%</span>
                    </div>
                    {mv.power > 0 && eff !== 1 && (
                      <div className={`text-[10px] font-bold ${eff > 1 ? 'text-green-600' : eff === 0 ? 'text-gray-500' : 'text-red-500'}`}>
                        {eff > 1 ? '▲ Siêu hiệu quả' : eff === 0 ? '✕ Vô dụng' : '▼ Kém hiệu quả'}
                      </div>
                    )}
                  </button>
                );
              })}
              <Button onClick={() => setPhase('menu')} className="col-span-2 text-sm py-1">◀ Quay lại</Button>
            </div>
          )}
          {phase === 'bag' && (
            <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
              {(Object.keys(ITEMS) as ItemId[]).filter((k) => (bs.inventory[k] ?? 0) > 0).map((k) => {
                const it = ITEMS[k];
                return (
                  <button key={k} className="sketch-btn bg-white p-2 text-left flex items-center gap-2" onClick={() => {
                    if (it.kind === 'ball') doAction({ type: 'item', itemId: k, targetIdx: bs.activeIdx });
                    else { setPendingItem(k); setPhase('bagTarget'); }
                  }}>
                    <span className="text-2xl">{it.emoji}</span>
                    <div className="flex-1">
                      <div className="font-bold text-sm">{it.name} <span className="text-gray-500">x{bs.inventory[k]}</span></div>
                      <div className="text-[10px] text-gray-600 leading-tight">{it.desc}</div>
                    </div>
                  </button>
                );
              })}
              {(Object.keys(ITEMS) as ItemId[]).every((k) => (bs.inventory[k] ?? 0) <= 0) && <div className="paper sketch-border-sm p-2 text-sm">Túi rỗng. Chỉ có bụi và một sợi tóc.</div>}
              <Button onClick={() => setPhase('menu')} className="text-sm py-1">◀ Quay lại</Button>
            </div>
          )}
          {(phase === 'bagTarget' || phase === 'party' || phase === 'forceSwitch') && (
            <div className="flex flex-col gap-2 max-h-72 overflow-y-auto">
              {bs.party.map((m, i) => {
                let disabled = false;
                if (phase === 'bagTarget') {
                  const it = ITEMS[pendingItem!];
                  disabled = it.kind === 'revive' ? m.hp > 0 : m.hp <= 0 || m.hp >= m.maxHp;
                } else {
                  disabled = i === bs.activeIdx || m.hp <= 0;
                }
                return (
                  <div key={m.uid} className={disabled ? 'opacity-50 pointer-events-none' : ''}>
                    <MonCard mon={m} compact selected={i === bs.activeIdx && phase !== 'bagTarget'} onClick={() => {
                      if (disabled) return;
                      if (phase === 'bagTarget') doAction({ type: 'item', itemId: pendingItem!, targetIdx: i });
                      else if (phase === 'party') doAction({ type: 'switch', idx: i });
                      else doForceSwitch(i);
                    }} />
                  </div>
                );
              })}
              {phase !== 'forceSwitch' && <Button onClick={() => setPhase('menu')} className="text-sm py-1">◀ Quay lại</Button>}
            </div>
          )}
          {phase === 'end' && (
            <div className="flex flex-col gap-2 h-full justify-center">
              <div className="text-center text-5xl">{bs.outcome === 'win' ? '🏆' : bs.outcome === 'lose' ? '💀' : bs.outcome === 'caught' ? '🎉' : '💨'}</div>
              <Button color="bg-yellow-300" onClick={() => onEnd(bs)} className="text-lg">Tiếp tục ▶</Button>
            </div>
          )}
          {phase === 'steps' && <div className="hidden sm:flex h-full items-center justify-center text-gray-500 text-sm italic">Đang diễn biến...</div>}
        </div>
      </div>
    </div>
  );
}
