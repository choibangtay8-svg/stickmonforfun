import { SPECIES, type Accessory, type Eyes } from '../data/stickmon';

interface Props {
  speciesId: string;
  size?: number;
  facing?: 'left' | 'right';
  fainted?: boolean;
  className?: string;
  shiny?: boolean;
}

function EyesSvg({ eyes, fainted }: { eyes: Eyes; fainted?: boolean }) {
  if (fainted) {
    return (
      <g stroke="#111" strokeWidth={2.2} strokeLinecap="round">
        <path d="M41 21 l6 6 M47 21 l-6 6" />
        <path d="M53 21 l6 6 M59 21 l-6 6" />
        <path d="M44 33 q6 -4 12 0" fill="none" />
      </g>
    );
  }
  switch (eyes) {
    case 'angry':
      return (
        <g fill="#111" stroke="#111" strokeWidth={2} strokeLinecap="round">
          <circle cx={44} cy={25} r={2.2} />
          <circle cx={56} cy={25} r={2.2} />
          <path d="M40 19 l8 3 M60 19 l-8 3" />
          <path d="M44 33 q6 -3 12 0" fill="none" />
        </g>
      );
    case 'derp':
      return (
        <g fill="#111">
          <circle cx={43} cy={24} r={3.5} />
          <circle cx={57} cy={27} r={2} />
          <path d="M44 33 q6 4 12 -1" fill="none" stroke="#111" strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    case 'sleepy':
      return (
        <g stroke="#111" strokeWidth={2.2} strokeLinecap="round" fill="none">
          <path d="M40 25 h8 M52 25 h8" />
          <ellipse cx={50} cy={33} rx={3} ry={2} fill="#111" />
        </g>
      );
    case 'happy':
      return (
        <g stroke="#111" strokeWidth={2.2} strokeLinecap="round" fill="none">
          <path d="M40 26 q4 -5 8 0 M52 26 q4 -5 8 0" />
          <path d="M42 31 q8 7 16 0" />
        </g>
      );
    case 'cool':
      return (
        <g>
          <rect x={38} y={21} width={10} height={6} rx={1.5} fill="#111" />
          <rect x={52} y={21} width={10} height={6} rx={1.5} fill="#111" />
          <path d="M48 23 h4 M36 22 l2 1 M62 23 l2 -1" stroke="#111" strokeWidth={2} />
          <path d="M45 33 q5 2 10 -1" fill="none" stroke="#111" strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    default:
      return (
        <g fill="#111">
          <circle cx={44} cy={25} r={2.4} />
          <circle cx={56} cy={25} r={2.4} />
          <path d="M45 32 q5 3 10 0" fill="none" stroke="#111" strokeWidth={2} strokeLinecap="round" />
        </g>
      );
  }
}

function Acc({ acc, color }: { acc: Accessory; color: string }) {
  switch (acc) {
    case 'flame':
      return <path d="M44 12 q2 -8 6 -12 q1 6 6 8 q3 -3 2 -7 q6 6 2 13 q-8 4 -16 -2z" fill="#f97316" stroke="#dc2626" strokeWidth={1.5} />;
    case 'bigflame':
      return (
        <g>
          <path d="M38 12 q3 -14 10 -20 q1 9 8 11 q5 -5 3 -12 q10 10 2 21 q-12 6 -23 0z" fill="#f97316" stroke="#dc2626" strokeWidth={1.5} />
          <path d="M45 11 q2 -7 5 -10 q1 4 4 6 q-1 5 -9 4z" fill="#fde047" />
        </g>
      );
    case 'dragon':
      return (
        <g>
          <path d="M36 12 q4 -16 12 -24 q1 10 10 13 q6 -6 4 -14 q12 12 2 25 q-14 8 -28 0z" fill="#ef4444" stroke="#7f1d1d" strokeWidth={1.5} />
          <path d="M44 11 q3 -9 6 -12 q1 5 5 7 q-1 6 -11 5z" fill="#fde047" />
          <path d="M48 50 l-26 -14 l4 16 l-8 4 l22 6z" fill="#b91c1c" stroke="#7f1d1d" strokeWidth={1.5} />
          <path d="M52 50 l26 -14 l-4 16 l8 4 l-22 6z" fill="#b91c1c" stroke="#7f1d1d" strokeWidth={1.5} />
          <path d="M50 80 q20 5 25 20" fill="none" stroke={color} strokeWidth={4} strokeLinecap="round" />
          <path d="M72 96 l6 -2 l-2 6z" fill="#f97316" />
        </g>
      );
    case 'bucket':
      return (
        <g>
          <path d="M36 14 l3 -12 h22 l3 12z" fill="#0ea5e9" stroke="#0369a1" strokeWidth={1.5} />
          <rect x={34} y={11} width={32} height={4} rx={1} fill="#0369a1" />
          <path d="M42 4 q8 -8 16 0" fill="none" stroke="#0369a1" strokeWidth={2} />
          <path d="M60 14 q6 6 4 12" fill="none" stroke="#38bdf8" strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    case 'snorkel':
      return (
        <g>
          <ellipse cx={50} cy={24} rx={14} ry={7} fill="none" stroke="#0369a1" strokeWidth={3} />
          <path d="M64 24 q10 -2 10 -15 v-6" fill="none" stroke="#0369a1" strokeWidth={3} strokeLinecap="round" />
          <rect x={71} y={0} width={6} height={5} fill="#f97316" />
        </g>
      );
    case 'kraken':
      return (
        <g fill="none" stroke={color} strokeWidth={4} strokeLinecap="round">
          <path d="M50 80 q-20 5 -22 30" />
          <path d="M50 80 q20 5 22 30" />
          <path d="M50 80 q-8 15 -4 32" />
          <path d="M50 80 q8 15 4 32" />
          <path d="M50 78 q-25 -5 -30 12" />
          <path d="M50 78 q25 -5 30 12" />
        </g>
      );
    case 'leaf':
      return (
        <g>
          <path d="M50 12 q0 -14 14 -14 q0 14 -14 14z" fill="#22c55e" stroke="#15803d" strokeWidth={1.5} />
          <path d="M50 12 q7 -7 12 -12" stroke="#15803d" strokeWidth={1} fill="none" />
        </g>
      );
    case 'bush':
      return (
        <g fill="#16a34a" stroke="#14532d" strokeWidth={1.2}>
          <circle cx={40} cy={10} r={8} />
          <circle cx={52} cy={5} r={9} />
          <circle cx={63} cy={11} r={7} />
          <circle cx={50} cy={13} r={7} />
          <circle cx={58} cy={3} r={2} fill="#f43f5e" stroke="none" />
          <circle cx={42} cy={6} r={2} fill="#f43f5e" stroke="none" />
        </g>
      );
    case 'tree':
      return (
        <g>
          <g fill="#15803d" stroke="#14532d" strokeWidth={1.2}>
            <circle cx={35} cy={8} r={11} />
            <circle cx={52} cy={0} r={13} />
            <circle cx={68} cy={8} r={10} />
            <circle cx={50} cy={12} r={9} />
          </g>
          <path d="M28 12 q-6 -10 -10 -6 M74 12 q6 -10 10 -6" stroke="#14532d" strokeWidth={3} fill="none" strokeLinecap="round" />
          <path d="M20 8 l-8 -6 l2 8" fill="#facc15" stroke="#a16207" strokeWidth={1} />
          <path d="M36 112 h28" stroke="#78350f" strokeWidth={4} strokeLinecap="round" />
        </g>
      );
    case 'bolt':
      return (
        <g fill="#facc15" stroke="#a16207" strokeWidth={1.5}>
          <path d="M36 16 l-4 -14 l10 10z" />
          <path d="M64 16 l4 -14 l-10 10z" />
          <circle cx={40} cy={30} r={2.5} fill="#f87171" stroke="none" />
          <circle cx={60} cy={30} r={2.5} fill="#f87171" stroke="none" />
        </g>
      );
    case 'bigbolt':
      return (
        <g fill="#facc15" stroke="#a16207" strokeWidth={1.5}>
          <path d="M40 13 l-8 -14 l6 4 l-2 -10 l10 14 l-6 -2z" />
          <path d="M52 12 l4 -16 l4 8 l6 -8 l-4 16z" />
          <path d="M60 14 l12 -10 l-6 12z" />
          <circle cx={40} cy={30} r={2.5} fill="#f87171" stroke="none" />
          <circle cx={60} cy={30} r={2.5} fill="#f87171" stroke="none" />
        </g>
      );
    case 'sheet':
      return (
        <g>
          <path d="M30 40 q0 -30 20 -30 q20 0 20 30 v50 l-7 -6 l-7 6 l-6 -6 l-6 6 l-7 -6 l-7 6z" fill="#f5f3ff" stroke="#7c3aed" strokeWidth={2} opacity={0.95} />
          <path d="M22 60 q-6 -10 8 -8 M78 60 q6 -10 -8 -8" fill="none" stroke="#7c3aed" strokeWidth={3} strokeLinecap="round" />
        </g>
      );
    case 'muscle':
      return (
        <g fill={color} stroke="#7f1d1d" strokeWidth={1.5}>
          <ellipse cx={36} cy={55} rx={9} ry={7} transform="rotate(-40 36 55)" />
          <ellipse cx={64} cy={55} rx={9} ry={7} transform="rotate(40 64 55)" />
          <ellipse cx={26} cy={45} rx={7} ry={5} transform="rotate(-60 26 45)" />
          <ellipse cx={74} cy={45} rx={7} ry={5} transform="rotate(60 74 45)" />
          <rect x={44} y={40} width={12} height={8} rx={3} />
          <rect x={44} y={50} width={12} height={8} rx={3} />
        </g>
      );
    case 'doge':
      return (
        <g>
          <path d="M38 16 l-6 -16 l12 10z M62 16 l6 -16 l-12 10z" fill="#f59e0b" stroke="#92400e" strokeWidth={1.5} />
          <ellipse cx={50} cy={30} rx={4} ry={3} fill="#111" />
          <path d="M52 34 q4 6 1 9 q-3 -3 -3 -8z" fill="#f43f5e" />
          <text x={72} y={20} fontSize={8} fill="#7c3aed" fontFamily="Comic Sans MS, cursive" fontWeight="bold">wow</text>
        </g>
      );
    case 'sloth':
      return (
        <g>
          <text x={62} y={12} fontSize={10} fill="#334155" fontWeight="bold">Z</text>
          <text x={70} y={6} fontSize={8} fill="#334155" fontWeight="bold">z</text>
          <text x={76} y={2} fontSize={6} fill="#334155" fontWeight="bold">z</text>
          <rect x={30} y={88} width={40} height={6} rx={3} fill="#fbbf24" opacity={0.6} />
        </g>
      );
    case 'candle':
      return (
        <g>
          <rect x={45} y={0} width={10} height={12} fill="#fef3c7" stroke="#d97706" strokeWidth={1.5} />
          <path d="M50 0 q-4 -6 0 -10 q4 4 0 10z" fill="#f97316" />
          <path d="M45 6 q2 3 -1 6 M55 4 q-2 4 1 8" stroke="#fde68a" strokeWidth={1.5} fill="none" />
        </g>
      );
    case 'mushroom':
      return (
        <g>
          <path d="M30 14 q20 -26 40 0z" fill="#ef4444" stroke="#991b1b" strokeWidth={1.5} />
          <circle cx={42} cy={6} r={3} fill="#fff" />
          <circle cx={55} cy={3} r={2.5} fill="#fff" />
          <circle cx={60} cy={10} r={2} fill="#fff" />
        </g>
      );
    case 'roach':
      return (
        <g stroke="#78350f" strokeWidth={2} fill="none" strokeLinecap="round">
          <path d="M44 12 q-6 -10 -14 -10 M56 12 q6 -10 14 -10" />
          <path d="M50 55 l-20 2 M50 62 l-20 8 M50 55 l20 2 M50 62 l20 8" />
          <ellipse cx={50} cy={60} rx={8} ry={16} fill="#92400e" opacity={0.5} stroke="none" />
        </g>
      );
    case 'crown':
      return (
        <g>
          <path d="M36 12 l0 -12 l7 6 l7 -9 l7 9 l7 -6 l0 12z" fill="#facc15" stroke="#a16207" strokeWidth={1.5} />
          <circle cx={43} cy={7} r={1.8} fill="#ef4444" />
          <circle cx={50} cy={5} r={1.8} fill="#3b82f6" />
          <circle cx={57} cy={7} r={1.8} fill="#22c55e" />
          <path d="M24 44 q-10 20 4 50 M76 44 q10 20 -4 50" fill="none" stroke="#7c3aed" strokeWidth={3} opacity={0.7} />
        </g>
      );
    case 'pacifier':
      return (
        <g>
          <circle cx={50} cy={33} r={4} fill="#f472b6" stroke="#be185d" strokeWidth={1.5} />
          <circle cx={50} cy={33} r={1.5} fill="#fbcfe8" />
          <path d="M46 8 q4 -8 8 0" fill="none" stroke="#111" strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    case 'sunglasses':
      return (
        <g>
          <path d="M40 8 q10 -8 20 0 l4 4 q-14 -4 -28 0z" fill="#111" />
          <path d="M40 8 q-8 4 -4 10" fill="none" stroke="#111" strokeWidth={2} />
        </g>
      );
    default:
      return null;
  }
}

export default function StickmonSprite({ speciesId, size = 120, facing = 'right', fainted, className = '', shiny }: Props) {
  const sp = SPECIES[speciesId];
  const color = shiny ? '#d946ef' : sp.color;
  const lying = sp.accessory === 'sloth';
  const isTree = sp.accessory === 'tree';
  const isKraken = sp.accessory === 'kraken';
  const isMuscle = sp.accessory === 'muscle';
  const s = (sp.scale ?? 1) * size;
  const transforms: string[] = [];
  if (facing === 'left') transforms.push('scale(-1,1) translate(-100,0)');
  if (lying && !fainted) transforms.push('rotate(-80 50 60) translate(0,10)');
  if (fainted) transforms.push('rotate(90 50 60) translate(0,-10)');

  return (
    <svg
      viewBox="-10 -15 120 135"
      width={s}
      height={s * 1.1}
      className={className}
      style={{ overflow: 'visible' }}
    >
      <g transform={transforms.join(' ')}>
        {/* shadow */}
        <ellipse cx={50} cy={113} rx={22} ry={4} fill="#000" opacity={0.15} />
        {/* body */}
        <g stroke={color} strokeWidth={isTree || isMuscle ? 7 : 4} strokeLinecap="round" fill="none">
          <line x1={50} y1={39} x2={50} y2={80} />
          {!isMuscle && <path d="M50 50 L30 66" />}
          {!isMuscle && <path d="M50 50 L70 66" />}
          {isMuscle && <path d="M50 46 L26 40 M50 46 L74 40" strokeWidth={6} />}
          {!isKraken && <path d="M50 80 L35 110" />}
          {!isKraken && <path d="M50 80 L65 110" />}
        </g>
        {/* head */}
        <circle cx={50} cy={25} r={14} fill="#fffbeb" stroke={color} strokeWidth={4} />
        <EyesSvg eyes={sp.eyes} fainted={fainted} />
        <Acc acc={sp.accessory} color={color} />
      </g>
    </svg>
  );
}
