import { STAGES } from '../data/stages';
import { SPECIES } from '../data/stickmon';
import type { MonInstance } from '../game/logic';
import StickmonSprite from './StickmonSprite';
import { Button, HpBar } from './ui';

interface Props {
  stageIdx: number;
  party: MonInstance[];
  money: number;
  badges: string[];
  trainerBeaten: boolean;
  name: string;
  finished: boolean;
  onExplore: () => void;
  onChallenge: () => void;
  onCenter: () => void;
  onShop: () => void;
  onParty: () => void;
  onDex: () => void;
  onNext: () => void;
  onPrev: () => void;
  onQuit: () => void;
}

export default function Hub(p: Props) {
  const stage = STAGES[p.stageIdx];
  const isLast = p.stageIdx === STAGES.length - 1;
  const avgLv = Math.round(p.party.reduce((s, m) => s + m.level, 0) / p.party.length);
  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-4">
      {/* header */}
      <div className="paper sketch-border p-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-3xl">🧍</span>
          <div>
            <div className="font-bold text-lg leading-tight">{p.name}</div>
            <div className="text-xs text-gray-600">💰 {p.money} Xu · Huy hiệu: {p.badges.length ? p.badges.join(' ') : 'chưa có 😢'}</div>
          </div>
        </div>
        <div className="flex gap-1 text-xs">
          {STAGES.map((s, i) => (
            <span key={s.id} title={s.name} className={`w-7 h-7 flex items-center justify-center rounded-full border-2 border-gray-800 ${i < p.stageIdx ? 'bg-green-400' : i === p.stageIdx ? 'bg-yellow-300 scale-110' : 'bg-gray-200 opacity-50'}`}>{s.emoji}</span>
          ))}
        </div>
        <Button className="text-xs py-1" onClick={p.onQuit}>💾 Lưu & Thoát</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* stage panel */}
        <div className={`md:col-span-2 sketch-border p-5 bg-gradient-to-br ${stage.bg} relative overflow-hidden`}>
          <div className="absolute -right-4 -bottom-4 text-[120px] opacity-20 select-none">{stage.emoji}</div>
          <div className="relative">
            <div className="text-xs font-bold uppercase tracking-widest text-gray-700">Chặng {p.stageIdx + 1}/{STAGES.length}</div>
            <div className="text-3xl font-black text-gray-900 drop-shadow-sm">{stage.emoji} {stage.name}</div>
            <div className="mt-2 space-y-1 text-gray-800 bg-white/50 sketch-border-sm p-2">
              {stage.desc.map((d, i) => <p key={i}>{d}</p>)}
            </div>
            <div className="mt-3 flex flex-wrap gap-2 text-xs">
              <span className="bg-white/70 sketch-border-sm px-2 py-0.5">Level đề xuất: <b>{stage.recommended}</b></span>
              <span className={`sketch-border-sm px-2 py-0.5 ${avgLv >= stage.recommended ? 'bg-green-200' : 'bg-red-200'}`}>Đội bạn TB: <b>Lv.{avgLv}</b> {avgLv >= stage.recommended ? '👍' : '😰 nên luyện thêm'}</span>
            </div>
            <div className="mt-2 text-xs text-gray-700">
              Stickmon hoang dã ở đây:{' '}
              {stage.wild.map((w) => SPECIES[w.speciesId].name).filter((v, i, a) => a.indexOf(v) === i).join(', ')}
            </div>

            <div className="grid grid-cols-2 gap-2 mt-4">
              <Button color="bg-green-300" onClick={p.onExplore} className="text-base">🌿 Vào bụi cỏ</Button>
              <Button color={p.trainerBeaten ? 'bg-gray-200' : 'bg-red-400'} onClick={p.onChallenge} className="text-base">
                {stage.trainer.emoji} {p.trainerBeaten ? 'Đấu lại' : 'Thách đấu'} {stage.trainer.name}
              </Button>
              <Button color="bg-pink-300" onClick={p.onCenter}>🏥 Trung tâm Stickmon</Button>
              <Button color="bg-amber-300" onClick={p.onShop}>🛒 Cửa hàng</Button>
              <Button color="bg-sky-300" onClick={p.onParty}>👥 Đội hình</Button>
              <Button color="bg-purple-300" onClick={p.onDex}>📖 Stickdex</Button>
              {p.stageIdx > 0 && <Button onClick={p.onPrev} className="text-sm">◀ Quay lại chặng trước</Button>}
              {p.trainerBeaten && !isLast && <Button color="bg-yellow-300" onClick={p.onNext} className="text-base col-start-2">➡️ Đi tới {STAGES[p.stageIdx + 1].name}</Button>}
              {p.trainerBeaten && isLast && p.finished && <div className="col-span-2 text-center font-bold bg-yellow-200 sketch-border-sm p-2">🏆 Bạn là NHÀ VÔ ĐỊCH! Thế giới que đã yên bình. Bạn có thể tiếp tục chơi.</div>}
            </div>
          </div>
        </div>

        {/* party panel */}
        <div className="paper sketch-border p-3">
          <div className="font-bold mb-2">Đội của bạn</div>
          <div className="flex flex-col gap-2">
            {p.party.map((m, i) => (
              <div key={m.uid} className={`flex items-center gap-2 bg-white/70 sketch-border-sm p-1.5 ${m.hp <= 0 ? 'opacity-60 grayscale' : ''}`}>
                <StickmonSprite speciesId={m.speciesId} size={40} fainted={m.hp <= 0} className={i === 0 ? 'anim-bob' : ''} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-xs"><b className="truncate">{SPECIES[m.speciesId].name}</b><span>Lv.{m.level}</span></div>
                  <HpBar hp={m.hp} maxHp={m.maxHp} height="h-1.5" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
