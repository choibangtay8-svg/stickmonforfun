import { useEffect, useState } from 'react';
import { SPECIES, STARTERS } from '../data/stickmon';
import { ITEMS, type ItemId, type Inventory } from '../data/items';
import { MOVES } from '../data/moves';
import { type MonInstance, xpForLevel } from '../game/logic';
import StickmonSprite from './StickmonSprite';
import { Button, DialogBox, MonCard, TypeBadge, HpBar } from './ui';

// ============ Dialog sequence ============
export function DialogSequence({ lines, speaker, onDone, emoji }: { lines: string[]; speaker?: string; onDone: () => void; emoji?: string }) {
  const [i, setI] = useState(0);
  return (
    <div className="flex flex-col items-center gap-4 w-full">
      {emoji && <div className="text-8xl anim-float drop-shadow-lg">{emoji}</div>}
      <DialogBox key={i} speaker={speaker} text={lines[i]} onNext={() => (i + 1 < lines.length ? setI(i + 1) : onDone())} />
      <div className="text-xs text-white/70">{i + 1}/{lines.length}</div>
    </div>
  );
}

// ============ Title ============
export function TitleScreen({ onNew, onContinue, hasSave }: { onNew: () => void; onContinue: () => void; hasSave: boolean }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 2500);
    return () => clearInterval(id);
  }, []);
  const ids = Object.keys(SPECIES);
  const showcase = ids[tick % ids.length];
  const taglines = ['Bắt hết đám que!', 'Gotta draw \'em all!', 'Không có đồ họa, chỉ có tình yêu.', 'Được vẽ trong giờ học Toán.', 'Ít nhất là không phải NFT.', 'Pokemon bản đồ họa thấp (rất thấp).', '100% que thật, không chất bảo quản.'];
  return (
    <div className="paper min-h-screen flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {ids.slice(0, 12).map((id, i) => (
          <div key={id} className="absolute" style={{ left: `${(i * 37) % 90}%`, top: `${(i * 53) % 85}%`, transform: `rotate(${(i * 47) % 60 - 30}deg)` }}>
            <StickmonSprite speciesId={id} size={60} />
          </div>
        ))}
      </div>
      <div className="relative z-10 flex flex-col items-center gap-4">
        <div className="text-7xl sm:text-9xl font-black tracking-tight text-gray-900 anim-wiggle" style={{ textShadow: '5px 5px 0 #facc15, 8px 8px 0 #1f2937' }}>
          STICKMON
        </div>
        <div className="text-xl sm:text-2xl text-gray-700 -mt-2">{taglines[tick % taglines.length]}</div>
        <div className="anim-enter" key={showcase}>
          <StickmonSprite speciesId={showcase} size={150} />
          <div className="font-bold">{SPECIES[showcase].name}</div>
        </div>
        <div className="flex flex-col gap-3 w-64 mt-2">
          {hasSave && <Button color="bg-green-400" onClick={onContinue} className="text-xl">▶ TIẾP TỤC</Button>}
          <Button color="bg-yellow-300" onClick={onNew} className="text-xl">✏️ GAME MỚI</Button>
        </div>
        <div className="text-xs text-gray-500 mt-4">© Bút Chì Studio™ · Không liên quan gì đến Nintendo, xin đừng kiện</div>
      </div>
    </div>
  );
}

// ============ Intro & Starter ============
const PROF_LINES = [
  'Chào mừng đến với thế giới STICKMON!',
  'Tôi là Giáo sư Cây Que. Người ta gọi tôi là Giáo sư vì tôi có kính. Thế thôi.',
  'Thế giới này đầy rẫy những sinh vật được vẽ vội trên giấy nháp, gọi là STICKMON.',
  'Có người nuôi chúng làm thú cưng. Có người bắt chúng đấu nhau. Có người dùng chúng làm que xiên cá viên. Đừng làm người thứ ba.',
  'Còn cháu... cháu là ai nhỉ? Tôi quên mất tên cháu rồi. Cháu nhắc lại giúp tôi.',
];

export function IntroScreen({ onDone }: { onDone: (name: string, starter: string) => void }) {
  const [step, setStep] = useState<'talk' | 'name' | 'starter' | 'confirm'>('talk');
  const [name, setName] = useState('');
  const [starter, setStarter] = useState<string | null>(null);
  const finalName = name.trim() || 'Que Con';

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-700 to-emerald-900 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl flex flex-col items-center gap-4">
        {step === 'talk' && <DialogSequence emoji="👨‍🔬" speaker="Giáo sư Cây Que" lines={PROF_LINES} onDone={() => setStep('name')} />}
        {step === 'name' && (
          <div className="paper sketch-border p-6 w-full flex flex-col gap-3 anim-pop">
            <div className="text-xl font-bold">Tên cháu là gì?</div>
            <input
              className="sketch-border-sm px-3 py-2 text-lg bg-white outline-none"
              placeholder="Que Con"
              maxLength={16}
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
            />
            <div className="text-sm text-gray-600">(Đừng đặt tên bậy, mẹ cháu sẽ đọc được)</div>
            <Button color="bg-yellow-300" onClick={() => setStep('starter')}>Xong!</Button>
          </div>
        )}
        {step === 'starter' && (
          <div className="w-full flex flex-col gap-4 anim-pop">
            <DialogBox speaker="Giáo sư Cây Que" text={`À, ${finalName}! Tên đẹp đấy (tôi nói dối). Giờ chọn một trong ba STICKMON này. Chọn kỹ nhé, không có hoàn trả.`} />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {STARTERS.map((id) => {
                const sp = SPECIES[id];
                return (
                  <button key={id} onClick={() => setStarter(id)} className={`paper sketch-border p-4 flex flex-col items-center gap-2 hover:bg-yellow-50 transition ${starter === id ? 'ring-4 ring-yellow-400' : ''}`}>
                    <StickmonSprite speciesId={id} size={110} className={starter === id ? 'anim-bob' : ''} />
                    <div className="font-bold text-lg">{sp.name}</div>
                    <TypeBadge type={sp.type} />
                    <div className="text-xs text-gray-600 text-center italic">"{sp.dex}"</div>
                  </button>
                );
              })}
            </div>
            <Button color="bg-yellow-300" disabled={!starter} onClick={() => setStep('confirm')} className="text-lg self-center px-8">Chọn con này!</Button>
          </div>
        )}
        {step === 'confirm' && starter && (
          <DialogSequence
            emoji="👨‍🔬"
            speaker="Giáo sư Cây Que"
            lines={[
              `${SPECIES[starter].name} à? Được, cũng được. Tôi thì thích con kia hơn nhưng thôi.`,
              'Đây là 5 Bóng Que và 2 Bánh Mì. Bóng để bắt Stickmon. Bánh mì để... ăn. Cho Stickmon ăn. Đừng ăn hết.',
              'Nhiệm vụ của cháu: đi qua 7 vùng đất, đánh bại các Thủ Lĩnh Gym, và tới Đỉnh Cao Vẽ Bậy để xử KẺ VẼ BẬY - kẻ đã vẽ tất cả chúng ta xấu như thế này.',
              'À, và thằng Tí hàng xóm đang đợi cháu ở cổng làng. Nó phiền lắm. Xử nó giúp tôi luôn.',
              'Đi đi! Và nhớ... đừng để bị ướt. Cháu là giấy mà.',
            ]}
            onDone={() => onDone(finalName, starter)}
          />
        )}
      </div>
    </div>
  );
}

// ============ Shop ============
const SHOP_LINES = ['Mua gì không? Không mua thì đứng đó làm gì?', 'Hàng xịn giá rẻ, không rẻ thì đừng mua!', 'Chào khách! Có tiền không đấy?', 'Bán hàng cả ngày mệt quá. Mua nhanh đi.'];
export function ShopScreen({ items, money, inventory, onBuy, onSell, onBack }: { items: ItemId[]; money: number; inventory: Inventory; onBuy: (id: ItemId) => void; onSell: (id: ItemId) => void; onBack: () => void }) {
  const [line] = useState(SHOP_LINES[Math.floor(Math.random() * SHOP_LINES.length)]);
  return (
    <div className="flex flex-col gap-4 w-full max-w-2xl mx-auto">
      <DialogBox speaker="🧓 Bà Chủ Tiệm" text={line} />
      <div className="paper sketch-border p-4">
        <div className="flex justify-between items-center mb-3">
          <span className="font-bold text-xl">🛒 Tiệm Tạp Hóa Que</span>
          <span className="font-bold text-lg bg-yellow-300 sketch-border-sm px-2">💰 {money} Xu</span>
        </div>
        <div className="flex flex-col gap-2">
          {items.map((id) => {
            const it = ITEMS[id];
            const have = inventory[id] ?? 0;
            return (
              <div key={id} className="flex items-center gap-3 bg-white/70 sketch-border-sm p-2">
                <span className="text-3xl">{it.emoji}</span>
                <div className="flex-1">
                  <div className="font-bold">{it.name} <span className="text-gray-500 text-sm">(có {have})</span></div>
                  <div className="text-xs text-gray-600">{it.desc}</div>
                </div>
                <div className="flex flex-col gap-1 items-end">
                  <Button color="bg-green-300" className="text-sm py-1" disabled={money < it.price} onClick={() => onBuy(id)}>Mua {it.price}💰</Button>
                  <Button className="text-xs py-0.5" disabled={have <= 0} onClick={() => onSell(id)}>Bán {Math.floor(it.price / 2)}💰</Button>
                </div>
              </div>
            );
          })}
        </div>
        <Button onClick={onBack} className="mt-4 w-full">◀ Về</Button>
      </div>
    </div>
  );
}

// ============ Party ============
export function PartyScreen({ party, box, onChange, onBack }: { party: MonInstance[]; box: MonInstance[]; onChange: (party: MonInstance[], box: MonInstance[]) => void; onBack: () => void }) {
  const [sel, setSel] = useState<number | null>(null);
  const [tab, setTab] = useState<'party' | 'box'>('party');
  const m = sel !== null ? (tab === 'party' ? party[sel] : box[sel]) : null;
  const sp = m ? SPECIES[m.speciesId] : null;

  return (
    <div className="flex flex-col lg:flex-row gap-4 w-full max-w-4xl mx-auto">
      <div className="flex-1 paper sketch-border p-4">
        <div className="flex gap-2 mb-3">
          <Button color={tab === 'party' ? 'bg-yellow-300' : 'bg-white'} className="text-sm" onClick={() => { setTab('party'); setSel(null); }}>👥 Đội ({party.length}/6)</Button>
          <Button color={tab === 'box' ? 'bg-yellow-300' : 'bg-white'} className="text-sm" onClick={() => { setTab('box'); setSel(null); }}>📦 Hộp của Giáo sư ({box.length})</Button>
        </div>
        <div className="flex flex-col gap-2 max-h-[60vh] overflow-y-auto pr-1">
          {(tab === 'party' ? party : box).map((mon, i) => (
            <MonCard key={mon.uid} mon={mon} selected={sel === i} onClick={() => setSel(i)} action={tab === 'party' && i === 0 ? 'ĐẦU' : undefined} />
          ))}
          {tab === 'box' && box.length === 0 && <div className="text-gray-600 italic">Hộp trống. Giáo sư đang buồn vì không có ai chơi cùng.</div>}
        </div>
        <Button onClick={onBack} className="mt-4 w-full">◀ Về</Button>
      </div>
      <div className="lg:w-80 paper sketch-border p-4 flex flex-col gap-2">
        {m && sp ? (
          <>
            <div className="flex justify-center"><StickmonSprite speciesId={m.speciesId} size={120} fainted={m.hp <= 0} className="anim-bob" /></div>
            <div className="text-center font-bold text-xl">{sp.name} <span className="text-sm text-gray-600">Lv.{m.level}</span></div>
            <div className="flex justify-center"><TypeBadge type={sp.type} /></div>
            <div className="text-xs italic text-gray-600 text-center">"{sp.dex}"</div>
            <HpBar hp={m.hp} maxHp={m.maxHp} showNum />
            <div className="grid grid-cols-3 text-center text-sm">
              <div className="bg-white/60 sketch-border-sm p-1">ATK<br /><b>{m.atk}</b></div>
              <div className="bg-white/60 sketch-border-sm p-1">DEF<br /><b>{m.def}</b></div>
              <div className="bg-white/60 sketch-border-sm p-1">SPD<br /><b>{m.spd}</b></div>
            </div>
            <div className="text-xs text-gray-600">XP: {m.xp} / {xpForLevel(m.level + 1)} (còn {Math.max(0, xpForLevel(m.level + 1) - m.xp)})</div>
            {sp.evolve && <div className="text-xs text-purple-700 font-bold">✨ Tiến hóa ở Lv.{sp.evolve.level}</div>}
            <div className="text-sm font-bold mt-1">Chiêu thức:</div>
            {m.moves.map((mid) => (
              <div key={mid} className="bg-white/60 sketch-border-sm p-1 text-xs flex items-center justify-between">
                <span className="font-bold">{MOVES[mid].name}</span>
                <span className="flex items-center gap-1"><TypeBadge type={MOVES[mid].type} small /> {MOVES[mid].power || '—'}</span>
              </div>
            ))}
            <div className="flex flex-col gap-1 mt-2">
              {tab === 'party' && sel !== null && sel > 0 && (
                <Button color="bg-yellow-300" className="text-sm" onClick={() => { const p = [...party]; const [x] = p.splice(sel, 1); p.unshift(x); onChange(p, box); setSel(0); }}>⬆ Đưa lên đầu đội</Button>
              )}
              {tab === 'party' && sel !== null && party.length > 1 && (
                <Button className="text-sm" onClick={() => { const p = [...party]; const [x] = p.splice(sel, 1); onChange(p, [...box, x]); setSel(null); }}>📦 Gửi vào hộp</Button>
              )}
              {tab === 'box' && sel !== null && party.length < 6 && (
                <Button color="bg-green-300" className="text-sm" onClick={() => { const b = [...box]; const [x] = b.splice(sel, 1); onChange([...party, x], b); setSel(null); }}>👥 Đưa vào đội</Button>
              )}
              {tab === 'box' && sel !== null && (
                <Button color="bg-red-300" className="text-sm" onClick={() => { if (confirm(`Thả ${sp.name} về tự nhiên? Nó sẽ buồn đấy.`)) { const b = [...box]; b.splice(sel, 1); onChange(party, b); setSel(null); } }}>🕊️ Thả tự do</Button>
              )}
            </div>
          </>
        ) : (
          <div className="text-gray-600 italic text-center my-auto">Chọn một Stickmon để xem chi tiết.<br />Chúng thích được chú ý.</div>
        )}
      </div>
    </div>
  );
}

// ============ Stickdex ============
export function DexScreen({ seen, caught, onBack }: { seen: string[]; caught: string[]; onBack: () => void }) {
  const [sel, setSel] = useState<string | null>(null);
  const all = Object.values(SPECIES);
  return (
    <div className="w-full max-w-4xl mx-auto paper sketch-border p-4">
      <div className="flex justify-between items-center mb-3">
        <span className="font-bold text-xl">📖 STICKDEX</span>
        <span className="text-sm">Đã thấy: {seen.length}/{all.length} · Đã bắt: {caught.length}/{all.length}</span>
      </div>
      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
        {all.map((sp) => {
          const isSeen = seen.includes(sp.id);
          const isCaught = caught.includes(sp.id);
          return (
            <button key={sp.id} onClick={() => isSeen && setSel(sp.id)} className={`sketch-border-sm bg-white/70 p-1 flex flex-col items-center ${isSeen ? 'hover:bg-yellow-50' : 'opacity-50'}`}>
              <div className={isSeen && !isCaught ? 'brightness-0 opacity-60' : isSeen ? '' : 'opacity-0'}>
                <StickmonSprite speciesId={sp.id} size={50} />
              </div>
              {!isSeen && <div className="-mt-12 mb-6 text-3xl">❓</div>}
              <div className="text-[10px] font-bold truncate w-full text-center">{isSeen ? sp.name : '???'}</div>
              {isCaught && <div className="text-[10px]">✅</div>}
            </button>
          );
        })}
      </div>
      {sel && (
        <div className="mt-4 flex gap-4 items-center bg-white/70 sketch-border-sm p-3 anim-pop">
          <StickmonSprite speciesId={sel} size={100} className={caught.includes(sel) ? 'anim-bob' : 'brightness-0 opacity-60'} />
          <div>
            <div className="font-bold text-lg">{SPECIES[sel].name} <TypeBadge type={SPECIES[sel].type} small /></div>
            <div className="text-sm italic">{caught.includes(sel) ? `"${SPECIES[sel].dex}"` : 'Bắt nó để đọc mô tả. Giáo sư lười viết cho con chưa bắt.'}</div>
            {caught.includes(sel) && <div className="text-xs text-gray-600 mt-1">Base: HP {SPECIES[sel].base.hp} · ATK {SPECIES[sel].base.atk} · DEF {SPECIES[sel].base.def} · SPD {SPECIES[sel].base.spd}</div>}
          </div>
        </div>
      )}
      <Button onClick={onBack} className="mt-4 w-full">◀ Về</Button>
    </div>
  );
}

// ============ Ending ============
const CREDITS = [
  '🎬 STICKMON', 'Một sản phẩm của Bút Chì Studio™', '',
  'Đạo diễn: Một cây bút bi hết mực', 'Kịch bản: Viết trong giờ học Toán', 'Đồ họa: Không có', 'Âm nhạc: Tự hát trong đầu đi', '',
  'Diễn viên:', 'Que Lửa - trong vai chính nó', 'Que Gián - vẫn còn sống', 'Thằng Tí - nghỉ chơi rồi', 'Kẻ Vẽ Bậy - đang học vẽ lớp 1', '',
  'Cảm ơn đặc biệt:', 'Giấy A4 Double A', 'Gôm Thiên Long', 'Cô giáo dạy Văn (xin đừng cho 0 điểm)', '',
  'Không có Stickmon nào bị thương trong quá trình làm game.', 'Có 3 cái bút bị hỏng.', '',
  '❤️ Cảm ơn bạn đã chơi! ❤️', 'Giờ đi làm bài tập đi.',
];
export function EndingScreen({ name, party, playtimeBattles, onContinue }: { name: string; party: MonInstance[]; playtimeBattles: number; onContinue: () => void }) {
  const [phase, setPhase] = useState<'dialog' | 'credits'>('dialog');
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-slate-900 to-black flex items-center justify-center p-4 overflow-hidden">
      {phase === 'dialog' ? (
        <div className="w-full max-w-2xl">
          <DialogSequence
            emoji="👨‍🔬"
            speaker="Giáo sư Cây Que"
            lines={[
              `${name}! Cháu đã làm được! Cháu đã đánh bại Kẻ Vẽ Bậy!`,
              'Từ nay thế giới Stickmon sẽ được vẽ đẹp hơn... có lẽ. Hắn ta mới học vẽ được 1 buổi.',
              `Cháu đã tham gia ${playtimeBattles} trận đấu. Đội của cháu thật tuyệt vời. Nhất là con đầu tiên, nó gánh còng lưng.`,
              'Cháu chính thức trở thành NHÀ VÔ ĐỊCH STICKMON! Phần thưởng là... danh hiệu này. Không có tiền. Xin lỗi.',
              'Cháu vẫn có thể quay lại luyện tập, bắt thêm Stickmon, hoặc đánh lại Kẻ Vẽ Bậy cho vui. Hắn rảnh lắm.',
            ]}
            onDone={() => setPhase('credits')}
          />
        </div>
      ) : (
        <div className="w-full max-w-xl text-center text-white flex flex-col items-center gap-6">
          <div className="text-6xl">🏆</div>
          <div className="text-4xl font-black" style={{ textShadow: '3px 3px 0 #facc15' }}>NHÀ VÔ ĐỊCH {name.toUpperCase()}</div>
          <div className="flex flex-wrap justify-center gap-2">
            {party.map((m) => (
              <div key={m.uid} className="paper sketch-border-sm p-2 flex flex-col items-center text-gray-900 anim-bob">
                <StickmonSprite speciesId={m.speciesId} size={60} />
                <div className="text-xs font-bold">{SPECIES[m.speciesId].name}</div>
                <div className="text-[10px]">Lv.{m.level}</div>
              </div>
            ))}
          </div>
          <div className="max-h-56 overflow-y-auto w-full text-lg leading-relaxed">
            {CREDITS.map((c, i) => <div key={i} className={c === '' ? 'h-4' : ''}>{c}</div>)}
          </div>
          <Button color="bg-yellow-300" onClick={onContinue} className="text-lg">Tiếp tục hành trình ▶</Button>
        </div>
      )}
    </div>
  );
}
