export type ItemId = 'stickball' | 'banhmi' | 'trada' | 'caphe' | 'superball';

export interface Item {
  id: ItemId;
  name: string;
  emoji: string;
  price: number;
  desc: string;
  kind: 'ball' | 'heal' | 'revive';
  value: number; // heal amount / ball multiplier / revive pct
}

export const ITEMS: Record<ItemId, Item> = {
  stickball: { id: 'stickball', name: 'Bóng Que', emoji: '🥎', price: 100, desc: 'Cục giấy vo tròn. Ném để bắt Stickmon.', kind: 'ball', value: 1 },
  superball: { id: 'superball', name: 'Bóng Xịn', emoji: '🎾', price: 300, desc: 'Cục giấy vo tròn nhưng có băng dính. Bắt dễ gấp đôi.', kind: 'ball', value: 2 },
  banhmi: { id: 'banhmi', name: 'Bánh Mì', emoji: '🥖', price: 150, desc: 'Bánh mì pate 15k. Hồi 50 HP.', kind: 'heal', value: 50 },
  trada: { id: 'trada', name: 'Trà Đá Đặc Biệt', emoji: '🧋', price: 400, desc: 'Trà đá vỉa hè huyền thoại. Hồi TOÀN BỘ HP.', kind: 'heal', value: 9999 },
  caphe: { id: 'caphe', name: 'Cà Phê Sữa', emoji: '☕', price: 500, desc: 'Hồi sinh Stickmon đã ngất với 50% HP. Tỉnh cả người.', kind: 'revive', value: 50 },
};

export type Inventory = Partial<Record<ItemId, number>>;
