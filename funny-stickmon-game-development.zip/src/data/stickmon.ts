import type { StickType } from './types';

export type Accessory =
  | 'none' | 'flame' | 'bigflame' | 'dragon' | 'bucket' | 'snorkel' | 'kraken'
  | 'leaf' | 'bush' | 'tree' | 'bolt' | 'bigbolt' | 'sheet' | 'muscle'
  | 'doge' | 'sloth' | 'candle' | 'mushroom' | 'roach' | 'crown' | 'pacifier' | 'sunglasses';

export type Eyes = 'dot' | 'angry' | 'derp' | 'sleepy' | 'happy' | 'cool';

export interface Species {
  id: string;
  name: string;
  type: StickType;
  base: { hp: number; atk: number; def: number; spd: number };
  baseXp: number;
  catchRate: number; // 0-255 higher easier
  color: string;
  accessory: Accessory;
  eyes: Eyes;
  scale?: number;
  dex: string;
  learnset: { level: number; move: string }[];
  evolve?: { level: number; into: string };
  ability?: 'gian' | 'lazy';
}

export const SPECIES: Record<string, Species> = {
  // ===== STARTERS =====
  quelua: {
    id: 'quelua', name: 'Que Lửa', type: 'Lửa',
    base: { hp: 39, atk: 52, def: 43, spd: 65 }, baseXp: 62, catchRate: 45,
    color: '#f97316', accessory: 'flame', eyes: 'dot', scale: 0.85,
    dex: 'Đầu lúc nào cũng cháy. Không phải vì giận, mà vì quên tắt bếp.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'dotvia' }, { level: 7, move: 'luatrai' }, { level: 12, move: 'hoithocay' }, { level: 20, move: 'phonghoa' }, { level: 30, move: 'nodiem' }],
    evolve: { level: 16, into: 'quechay' },
  },
  quechay: {
    id: 'quechay', name: 'Que Cháy', type: 'Lửa',
    base: { hp: 58, atk: 64, def: 58, spd: 80 }, baseXp: 142, catchRate: 45,
    color: '#ea580c', accessory: 'bigflame', eyes: 'angry', scale: 1,
    dex: 'Đã cháy được nửa thân. Vẫn khẳng định "tao ổn".',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'dotvia' }, { level: 7, move: 'luatrai' }, { level: 12, move: 'hoithocay' }, { level: 20, move: 'phonghoa' }, { level: 30, move: 'nodiem' }],
    evolve: { level: 32, into: 'quediemrong' },
  },
  quediemrong: {
    id: 'quediemrong', name: 'Que Diêm Rồng', type: 'Lửa',
    base: { hp: 78, atk: 84, def: 78, spd: 100 }, baseXp: 240, catchRate: 45,
    color: '#dc2626', accessory: 'dragon', eyes: 'cool', scale: 1.15,
    dex: 'Rồng? Không. Là que diêm mọc cánh. Nhưng đừng nói với nó.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'dotvia' }, { level: 7, move: 'luatrai' }, { level: 12, move: 'hoithocay' }, { level: 20, move: 'phonghoa' }, { level: 30, move: 'nodiem' }],
  },
  quenuoc: {
    id: 'quenuoc', name: 'Que Nước', type: 'Nước',
    base: { hp: 44, atk: 48, def: 65, spd: 43 }, baseXp: 63, catchRate: 45,
    color: '#0ea5e9', accessory: 'bucket', eyes: 'dot', scale: 0.85,
    dex: 'Đội xô nước đi khắp nơi. Hỏi tại sao thì bảo "cho mát".',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'tatnuoc' }, { level: 8, move: 'tedam' }, { level: 13, move: 'uongtrada' }, { level: 20, move: 'xitnuoc' }, { level: 30, move: 'songthanmini' }],
    evolve: { level: 16, into: 'quexo' },
  },
  quexo: {
    id: 'quexo', name: 'Que Xô', type: 'Nước',
    base: { hp: 59, atk: 63, def: 80, spd: 58 }, baseXp: 142, catchRate: 45,
    color: '#0284c7', accessory: 'snorkel', eyes: 'happy', scale: 1,
    dex: 'Lên đời đeo ống thở. Chưa từng lặn bao giờ.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'tatnuoc' }, { level: 8, move: 'tedam' }, { level: 13, move: 'uongtrada' }, { level: 20, move: 'xitnuoc' }, { level: 30, move: 'songthanmini' }],
    evolve: { level: 32, into: 'quethuyquai' },
  },
  quethuyquai: {
    id: 'quethuyquai', name: 'Que Thủy Quái', type: 'Nước',
    base: { hp: 79, atk: 83, def: 100, spd: 78 }, baseXp: 240, catchRate: 45,
    color: '#1d4ed8', accessory: 'kraken', eyes: 'cool', scale: 1.15,
    dex: 'Có xúc tu. Dùng chủ yếu để gãi lưng.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'tatnuoc' }, { level: 8, move: 'tedam' }, { level: 13, move: 'uongtrada' }, { level: 20, move: 'xitnuoc' }, { level: 30, move: 'songthanmini' }],
  },
  queco: {
    id: 'queco', name: 'Que Cỏ', type: 'Cỏ',
    base: { hp: 45, atk: 49, def: 49, spd: 45 }, baseXp: 64, catchRate: 45,
    color: '#22c55e', accessory: 'leaf', eyes: 'dot', scale: 0.85,
    dex: 'Có một chiếc lá mọc trên đầu. Nó tưởng đó là tóc.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'nemla' }, { level: 7, move: 'quanghop' }, { level: 12, move: 'requan' }, { level: 20, move: 'nemdua' }, { level: 30, move: 'codaimoc' }],
    evolve: { level: 16, into: 'quebui' },
  },
  quebui: {
    id: 'quebui', name: 'Que Bụi', type: 'Cỏ',
    base: { hp: 60, atk: 62, def: 63, spd: 60 }, baseXp: 142, catchRate: 45,
    color: '#16a34a', accessory: 'bush', eyes: 'happy', scale: 1,
    dex: 'Tóc thành bụi rậm. Chim đã làm tổ bên trong.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'nemla' }, { level: 7, move: 'quanghop' }, { level: 12, move: 'requan' }, { level: 20, move: 'nemdua' }, { level: 30, move: 'codaimoc' }],
    evolve: { level: 32, into: 'quecothu' },
  },
  quecothu: {
    id: 'quecothu', name: 'Que Cổ Thụ', type: 'Cỏ',
    base: { hp: 80, atk: 82, def: 83, spd: 80 }, baseXp: 240, catchRate: 45,
    color: '#15803d', accessory: 'tree', eyes: 'cool', scale: 1.15,
    dex: 'Đứng yên 3 tiếng là có người tới buộc võng.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'nemla' }, { level: 7, move: 'quanghop' }, { level: 12, move: 'requan' }, { level: 20, move: 'nemdua' }, { level: 30, move: 'codaimoc' }],
  },
  // ===== WILD =====
  quechuot: {
    id: 'quechuot', name: 'Que Chuột', type: 'Điện',
    base: { hp: 35, atk: 55, def: 40, spd: 90 }, baseXp: 112, catchRate: 190,
    color: '#facc15', accessory: 'bolt', eyes: 'happy', scale: 0.85,
    dex: 'Giống một linh vật nổi tiếng nhưng luật sư bảo không được nói.',
    learnset: [{ level: 1, move: 'giatnhe' }, { level: 1, move: 'culet' }, { level: 9, move: 'sacpin' }, { level: 14, move: 'chamodien' }, { level: 26, move: 'setdanh' }],
    evolve: { level: 22, into: 'queset' },
  },
  queset: {
    id: 'queset', name: 'Que Sét', type: 'Điện',
    base: { hp: 60, atk: 90, def: 55, spd: 110 }, baseXp: 218, catchRate: 75,
    color: '#eab308', accessory: 'bigbolt', eyes: 'angry', scale: 1.05,
    dex: 'Tóc dựng vĩnh viễn. Tiết kiệm tiền gel.',
    learnset: [{ level: 1, move: 'giatnhe' }, { level: 1, move: 'culet' }, { level: 9, move: 'sacpin' }, { level: 14, move: 'chamodien' }, { level: 22, move: 'matwifi' }, { level: 26, move: 'setdanh' }],
  },
  quema: {
    id: 'quema', name: 'Que Ma', type: 'Ma',
    base: { hp: 30, atk: 65, def: 30, spd: 80 }, baseXp: 95, catchRate: 150,
    color: '#a855f7', accessory: 'sheet', eyes: 'derp', scale: 0.9,
    dex: 'Trùm khăn trải giường. Mẹ nó vẫn đang tìm khăn.',
    learnset: [{ level: 1, move: 'hudoa' }, { level: 1, move: 'canhe' }, { level: 10, move: 'hutvia' }, { level: 15, move: 'bongde' }, { level: 28, move: 'amanhdeadline' }],
  },
  quecobap: {
    id: 'quecobap', name: 'Que Cơ Bắp', type: 'Đấm',
    base: { hp: 70, atk: 80, def: 50, spd: 35 }, baseXp: 130, catchRate: 120,
    color: '#ef4444', accessory: 'muscle', eyes: 'angry', scale: 1.05,
    dex: 'Tập gym 6 ngày/tuần. Vẫn là que. Nhưng là que TỰ TIN.',
    learnset: [{ level: 1, move: 'tatyeu' }, { level: 1, move: 'gongco' }, { level: 12, move: 'daxoay' }, { level: 18, move: 'ganggang' }, { level: 30, move: 'dampchetluon' }],
  },
  quedoge: {
    id: 'quedoge', name: 'Que Doge', type: 'Meme',
    base: { hp: 50, atk: 60, def: 45, spd: 70 }, baseXp: 105, catchRate: 140,
    color: '#f59e0b', accessory: 'doge', eyes: 'derp', scale: 0.95,
    dex: 'Much stick. Very wow. So que.',
    learnset: [{ level: 1, move: 'canhe' }, { level: 1, move: 'culet' }, { level: 8, move: 'chuithe' }, { level: 14, move: 'nhaydance' }, { level: 24, move: 'memebungno' }],
  },
  queluoi: {
    id: 'queluoi', name: 'Que Lười', type: 'Meme',
    base: { hp: 110, atk: 60, def: 60, spd: 15 }, baseXp: 140, catchRate: 100,
    color: '#a3a3a3', accessory: 'sloth', eyes: 'sleepy', scale: 1,
    dex: 'Chưa từng đứng dậy. Nằm đánh nhau. Vẫn thắng.',
    learnset: [{ level: 1, move: 'namngu' }, { level: 1, move: 'hucdau' }, { level: 15, move: 'tusuong' }, { level: 25, move: 'memebungno' }],
  },
  quenen: {
    id: 'quenen', name: 'Que Nến', type: 'Lửa',
    base: { hp: 45, atk: 60, def: 40, spd: 55 }, baseXp: 90, catchRate: 160,
    color: '#fb923c', accessory: 'candle', eyes: 'dot', scale: 0.85,
    dex: 'Chỉ xuất hiện khi mất điện. Khi có điện thì tủi thân.',
    learnset: [{ level: 1, move: 'dotvia' }, { level: 1, move: 'canhe' }, { level: 12, move: 'hoithocay' }, { level: 22, move: 'phonghoa' }],
  },
  quenam: {
    id: 'quenam', name: 'Que Nấm', type: 'Cỏ',
    base: { hp: 55, atk: 45, def: 60, spd: 30 }, baseXp: 85, catchRate: 170,
    color: '#84cc16', accessory: 'mushroom', eyes: 'happy', scale: 0.85,
    dex: 'Mọc sau mưa. Đừng ăn. Đã có người thử rồi và giờ họ thấy màu sắc.',
    learnset: [{ level: 1, move: 'nemla' }, { level: 1, move: 'hucdau' }, { level: 10, move: 'quanghop' }, { level: 16, move: 'requan' }, { level: 26, move: 'codaimoc' }],
  },
  quebom: {
    id: 'quebom', name: 'Que Bơm', type: 'Nước',
    base: { hp: 50, atk: 55, def: 50, spd: 60 }, baseXp: 90, catchRate: 160,
    color: '#38bdf8', accessory: 'snorkel', eyes: 'derp', scale: 0.85,
    dex: 'Là cái bơm xe đạp thành tinh. Chuyên xịt nước vào mặt người khác.',
    learnset: [{ level: 1, move: 'tatnuoc' }, { level: 1, move: 'culet' }, { level: 12, move: 'tedam' }, { level: 18, move: 'xitnuoc' }, { level: 28, move: 'songthanmini' }],
  },
  quegian: {
    id: 'quegian', name: 'Que Gián', type: 'Meme',
    base: { hp: 30, atk: 35, def: 35, spd: 75 }, baseXp: 50, catchRate: 255,
    color: '#78350f', accessory: 'roach', eyes: 'derp', scale: 0.75, ability: 'gian',
    dex: 'Không thể bị tiêu diệt hoàn toàn. Khả năng: sống sót 1 HP một lần mỗi trận.',
    learnset: [{ level: 1, move: 'canhe' }, { level: 1, move: 'culet' }, { level: 8, move: 'chuithe' }, { level: 16, move: 'nhaydance' }],
  },
  quenhi: {
    id: 'quenhi', name: 'Que Nhí', type: 'Meme',
    base: { hp: 40, atk: 30, def: 30, spd: 50 }, baseXp: 40, catchRate: 255,
    color: '#f9a8d4', accessory: 'pacifier', eyes: 'happy', scale: 0.7,
    dex: 'Còn ngậm ti giả. Cắn cũng đau ra phết.',
    learnset: [{ level: 1, move: 'culet' }, { level: 5, move: 'canhe' }, { level: 12, move: 'tusuong' }],
    evolve: { level: 14, into: 'quedoge' },
  },
  queboss: {
    id: 'queboss', name: 'Que Tối Thượng', type: 'Ma',
    base: { hp: 100, atk: 110, def: 90, spd: 95 }, baseXp: 340, catchRate: 3,
    color: '#111827', accessory: 'crown', eyes: 'cool', scale: 1.25,
    dex: 'Được vẽ bằng bút bi Thiên Long hết mực. Huyền thoại.',
    learnset: [{ level: 1, move: 'bongde' }, { level: 1, move: 'hudoa' }, { level: 1, move: 'amanhdeadline' }, { level: 1, move: 'dampchetluon' }],
  },
  quengau: {
    id: 'quengau', name: 'Que Ngầu', type: 'Meme',
    base: { hp: 65, atk: 75, def: 60, spd: 85 }, baseXp: 160, catchRate: 60,
    color: '#0f172a', accessory: 'sunglasses', eyes: 'cool', scale: 1,
    dex: 'Đeo kính râm cả ban đêm. Va vào cột 3 lần/ngày.',
    learnset: [{ level: 1, move: 'hucdau' }, { level: 1, move: 'chuithe' }, { level: 14, move: 'nhaydance' }, { level: 20, move: 'tusuong' }, { level: 26, move: 'memebungno' }],
  },
};

export const STARTERS = ['quelua', 'quenuoc', 'queco'];
