export type StickType = 'Lửa' | 'Nước' | 'Cỏ' | 'Điện' | 'Meme' | 'Ma' | 'Đấm';

export const TYPE_COLORS: Record<StickType, string> = {
  Lửa: 'bg-orange-500',
  Nước: 'bg-sky-500',
  Cỏ: 'bg-green-500',
  Điện: 'bg-yellow-400 text-black',
  Meme: 'bg-pink-400',
  Ma: 'bg-purple-600',
  Đấm: 'bg-red-700',
};

export const TYPE_EMOJI: Record<StickType, string> = {
  Lửa: '🔥',
  Nước: '💧',
  Cỏ: '🌿',
  Điện: '⚡',
  Meme: '🤡',
  Ma: '👻',
  Đấm: '👊',
};

// attacker -> defender -> multiplier
const CHART: Partial<Record<StickType, Partial<Record<StickType, number>>>> = {
  Lửa: { Cỏ: 2, Nước: 0.5, Lửa: 0.5 },
  Nước: { Lửa: 2, Cỏ: 0.5, Nước: 0.5 },
  Cỏ: { Nước: 2, Lửa: 0.5, Cỏ: 0.5, Điện: 2 },
  Điện: { Nước: 2, Cỏ: 0.5, Điện: 0.5 },
  Meme: { Đấm: 2, Ma: 0 },
  Ma: { Ma: 2, Meme: 0, Đấm: 2 },
  Đấm: { Meme: 2, Ma: 0 },
};

export function effectiveness(atk: StickType, def: StickType): number {
  return CHART[atk]?.[def] ?? 1;
}
