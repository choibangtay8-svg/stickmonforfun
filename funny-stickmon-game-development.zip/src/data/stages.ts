import type { ItemId } from './items';

export interface WildEntry { speciesId: string; min: number; max: number; weight: number }

export interface TrainerDef {
  name: string;
  title: string;
  emoji: string;
  intro: string[];
  party: { speciesId: string; level: number }[];
  reward: number;
  winText: string[]; // when player wins
  loseText: string[]; // when player loses
  badge?: string;
}

export interface StageDef {
  id: string;
  name: string;
  emoji: string;
  bg: string; // tailwind gradient classes
  desc: string[];
  wild: WildEntry[];
  trainer: TrainerDef;
  shop: ItemId[];
  recommended: number;
  events: string[]; // random funny events when exploring
}

export const STAGES: StageDef[] = [
  {
    id: 'lang',
    name: 'Làng Que Củi',
    emoji: '🏡',
    bg: 'from-lime-200 via-green-100 to-emerald-200',
    desc: ['Một ngôi làng yên bình. Mọi người ở đây đều được vẽ bằng bút chì 2B.', 'Thằng Tí hàng xóm đang đứng chặn cổng làng với vẻ mặt khiêu khích.'],
    wild: [
      { speciesId: 'quenhi', min: 2, max: 4, weight: 4 },
      { speciesId: 'quegian', min: 2, max: 4, weight: 4 },
      { speciesId: 'quechuot', min: 3, max: 4, weight: 1 },
    ],
    trainer: {
      name: 'Thằng Tí', title: 'Hàng Xóm Phiền Phức', emoji: '😤',
      intro: ['Ê! Mày tưởng mày ngon hả?', 'Tao cũng có Stickmon nè! Giáo sư cho tao con MẠNH HƠN của mày!', 'Quẩy thôi!'],
      party: [{ speciesId: 'quenhi', level: 3 }, { speciesId: 'STARTER_COUNTER', level: 5 }],
      reward: 300,
      winText: ['CÁI GÌ?! Tao... tao chưa sẵn sàng thôi!', 'Lần sau gặp lại tao sẽ mạnh hơn! Nhớ đấy!', '(Tí bỏ chạy về mách mẹ.)'],
      loseText: ['Hahaha! Yếu như que tăm!', 'Về luyện thêm đi con!'],
    },
    shop: ['stickball', 'banhmi'],
    recommended: 6,
    events: [
      'Bạn nhặt được một tờ giấy nháp. Trên đó viết: "Nhớ mua nước mắm". Vô dụng.',
      'Một bà cụ nhìn bạn và nói: "Hồi xưa bà cũng là huấn luyện viên đó". Bà cụ là que 3D. Rất đáng ngờ.',
      'Bạn thấy một con Que Gián. Nó thấy bạn. Cả hai đều bỏ chạy.',
    ],
  },
  {
    id: 'rung',
    name: 'Rừng Bút Chì',
    emoji: '🌲',
    bg: 'from-green-300 via-emerald-200 to-teal-200',
    desc: ['Khu rừng nơi mọi cái cây đều là bút chì cắm ngược.', 'Có mùi gôm tẩy trong không khí. Anh Bảo Vệ Rừng đang ngủ gật ở chốt canh.'],
    wild: [
      { speciesId: 'quechuot', min: 5, max: 8, weight: 3 },
      { speciesId: 'quenam', min: 5, max: 8, weight: 3 },
      { speciesId: 'quegian', min: 4, max: 7, weight: 2 },
      { speciesId: 'quedoge', min: 6, max: 8, weight: 2 },
      { speciesId: 'quenhi', min: 4, max: 6, weight: 1 },
    ],
    trainer: {
      name: 'Anh Bảo Vệ', title: 'Bảo Vệ Rừng Ca Đêm', emoji: '💂',
      intro: ['Hả? Ai đó? Tôi không ngủ nhé, tôi đang... nhắm mắt suy nghĩ.', 'Muốn qua rừng phải đấu với tôi! Quy định của rừng!', '(Quy định anh ấy tự nghĩ ra.)'],
      party: [{ speciesId: 'quenam', level: 8 }, { speciesId: 'quenam', level: 9 }, { speciesId: 'quebui', level: 11 }],
      reward: 600,
      winText: ['Thôi được, qua đi. Đằng nào tôi cũng sắp hết ca.', 'Nhận lấy Huy Hiệu Lá Cây này. Tôi nhặt ở đâu đó.'],
      loseText: ['Đã bảo là quy định của rừng mà!', 'Về đi, tôi ngủ tiếp đây.'],
      badge: '🍃',
    },
    shop: ['stickball', 'banhmi', 'caphe'],
    recommended: 12,
    events: [
      'Bạn giẫm phải phân Que Chuột. Nó có hình... tia sét. Ấn tượng.',
      'Một cái cây bút chì rơi trúng đầu. Bạn nảy ra ý tưởng viết tiểu thuyết. Rồi quên ngay.',
      'Bạn tìm thấy một Bóng Que trong bụi rậm!|stickball',
      'Bạn thấy một tổ chim bên trong tóc một Que Bụi đang ngủ. Đáng yêu và đáng lo.',
    ],
  },
  {
    id: 'hang',
    name: 'Hang Gôm Tẩy',
    emoji: '🕳️',
    bg: 'from-slate-400 via-purple-200 to-indigo-300',
    desc: ['Hang động tối om. Nghe đồn ai vào đây cũng bị tẩy mất một phần cơ thể.', 'Sâu trong hang là phòng Gym của Cô Giáo Dạy Văn. Cô ấy rất đáng sợ.'],
    wild: [
      { speciesId: 'quema', min: 10, max: 13, weight: 4 },
      { speciesId: 'quenen', min: 10, max: 13, weight: 3 },
      { speciesId: 'quecobap', min: 11, max: 13, weight: 2 },
      { speciesId: 'quegian', min: 9, max: 12, weight: 1 },
    ],
    trainer: {
      name: 'Cô Giáo Dạy Văn', title: 'Thủ Lĩnh Gym Hệ Ma', emoji: '👩‍🏫',
      intro: ['Em vào lớp muộn 3 phút. Đứng đó.', 'Em đã làm bài tập về nhà chưa? CHƯA À?', 'Vậy thì hôm nay cô sẽ dạy em một bài học về... DEADLINE.'],
      party: [{ speciesId: 'quema', level: 14 }, { speciesId: 'quema', level: 15 }, { speciesId: 'quenen', level: 16 }],
      reward: 1000,
      winText: ['...Được. Em được 8 điểm. Cô không bao giờ cho 10.', 'Huy Hiệu Phấn Trắng này là của em. Nhớ nộp bài đúng hạn.'],
      loseText: ['Về viết bản kiểm điểm 3 trang. Không được dùng AI.'],
      badge: '📝',
    },
    shop: ['stickball', 'superball', 'banhmi', 'caphe'],
    recommended: 17,
    events: [
      'Bạn nghe tiếng thì thầm: "Mai nộp báo cáo nhé..." Toát mồ hôi lạnh.',
      'Một Que Ma bay qua và hù bạn. Bạn hù lại. Nó khóc. Bạn thấy hơi tội.',
      'Bạn tìm thấy 200 Xu rơi trong khe đá!|money:200',
      'Bạn đụng phải cục gôm khổng lồ. Một phần tóc bạn biến mất. Không sao, vẫn đẹp trai.',
    ],
  },
  {
    id: 'bien',
    name: 'Bãi Biển Giấy A4',
    emoji: '🏖️',
    bg: 'from-sky-300 via-cyan-100 to-amber-100',
    desc: ['Bãi biển với cát màu trắng tinh khôi (vì là giấy). Sóng biển là mực xanh.', 'Chú Bán Trà Đá đang ngồi dưới cây dù, thách đấu mọi khách qua đường.'],
    wild: [
      { speciesId: 'quebom', min: 15, max: 18, weight: 4 },
      { speciesId: 'quedoge', min: 15, max: 18, weight: 3 },
      { speciesId: 'queluoi', min: 16, max: 18, weight: 2 },
      { speciesId: 'quechuot', min: 15, max: 17, weight: 2 },
    ],
    trainer: {
      name: 'Chú Bán Trà Đá', title: 'Thủ Lĩnh Gym Hệ Nước', emoji: '🧔',
      intro: ['Trà đá không cháu? 3 nghìn một cốc.', 'Không uống à? Vậy đấu với chú. Thua thì mua trà.', 'Chú bán ở đây 30 năm rồi, chưa ai thắng được chú (vì chưa ai đấu).'],
      party: [{ speciesId: 'quebom', level: 19 }, { speciesId: 'queluoi', level: 20 }, { speciesId: 'quexo', level: 22 }],
      reward: 1500,
      winText: ['Ơ hay! Cháu mạnh đấy!', 'Cầm Huy Hiệu Cốc Nhựa này. Mà vẫn phải mua trà nhé. 3 nghìn.'],
      loseText: ['Đã bảo rồi. Mua trà đi cháu. 3 nghìn.'],
      badge: '🥤',
    },
    shop: ['stickball', 'superball', 'banhmi', 'trada', 'caphe'],
    recommended: 23,
    events: [
      'Bạn đắp lâu đài cát. Sóng mực xanh cuốn trôi. Bạn khóc bằng mực đen.',
      'Một Que Lười nằm phơi nắng. Nó đã nằm đây từ tuần trước.',
      'Bạn tìm thấy một Bóng Xịn dạt vào bờ!|superball',
      'Chú bán trà đá hét: "TRÀ ĐÁ ĐÂYYY". Bạn giật mình rơi dép.',
    ],
  },
  {
    id: 'gym',
    name: 'Phòng Gym Thật',
    emoji: '🏋️',
    bg: 'from-red-300 via-orange-200 to-rose-200',
    desc: ['Một phòng gym thật sự. Mùi mồ hôi và protein bay lảng vảng.', 'Gymer Đức đang tập cơ tay thứ 3 tiếng liên tục và gào lên mỗi lần nâng tạ.'],
    wild: [
      { speciesId: 'quecobap', min: 21, max: 24, weight: 4 },
      { speciesId: 'quengau', min: 22, max: 24, weight: 2 },
      { speciesId: 'quedoge', min: 21, max: 23, weight: 2 },
      { speciesId: 'queluoi', min: 21, max: 24, weight: 2 },
    ],
    trainer: {
      name: 'Gymer Đức', title: 'Thủ Lĩnh Gym Hệ Đấm', emoji: '💪',
      intro: ['HÔM NAY LÀ NGÀY TẬP CHÂN! Ủa nhầm, NGÀY ĐẤU!', 'Mày có biết 1 rep max của tao là bao nhiêu không? TAO CŨNG KHÔNG!', 'LIGHT WEIGHT BABYYY!'],
      party: [{ speciesId: 'quecobap', level: 25 }, { speciesId: 'quengau', level: 26 }, { speciesId: 'quecobap', level: 28 }],
      reward: 2000,
      winText: ['HỰ... Hôm nay tao chưa uống pre-workout thôi!', 'Cầm Huy Hiệu Tạ Đơn. Nhớ ăn đủ protein.'],
      loseText: ['YẾU! Về tập thêm rồi quay lại. NO PAIN NO GAIN!'],
      badge: '🏋️',
    },
    shop: ['stickball', 'superball', 'banhmi', 'trada', 'caphe'],
    recommended: 29,
    events: [
      'Bạn thử nâng tạ 2kg. Thất bại. Que Cơ Bắp bên cạnh nhìn bạn thương hại.',
      'Một gymer hỏi: "Bao nhiêu set nữa?" Bạn không tập. Bạn chỉ đi ngang qua.',
      'Bạn tìm thấy một chai Cà Phê Sữa ai bỏ quên!|caphe',
      'Bạn nhìn vào gương phòng gym. Gương nói: "Cố lên". Gương biết nói. Bạn không hỏi thêm.',
    ],
  },
  {
    id: 'thap',
    name: 'Tháp Wifi',
    emoji: '📡',
    bg: 'from-yellow-200 via-amber-100 to-sky-200',
    desc: ['Tòa tháp cao nhất vùng, phát wifi miễn phí (mật khẩu: 12345678).', 'Ông Thợ Điện đang trèo trên cột, sửa gì đó mà ông cũng không rõ.'],
    wild: [
      { speciesId: 'quechuot', min: 27, max: 30, weight: 3 },
      { speciesId: 'queset', min: 28, max: 31, weight: 2 },
      { speciesId: 'quema', min: 27, max: 30, weight: 2 },
      { speciesId: 'quenen', min: 27, max: 29, weight: 2 },
      { speciesId: 'quengau', min: 28, max: 30, weight: 1 },
    ],
    trainer: {
      name: 'Ông Thợ Điện', title: 'Thủ Lĩnh Gym Hệ Điện', emoji: '👷',
      intro: ['Cháu ơi, dây này màu đỏ hay màu xanh? Ông mù màu.', 'Thôi kệ, cắt đại! ... Ơ, sao tối thế?', 'Mà thôi, đấu đi. Ông có mấy con Que Sét ngon lắm.'],
      party: [{ speciesId: 'quechuot', level: 31 }, { speciesId: 'queset', level: 32 }, { speciesId: 'queset', level: 34 }],
      reward: 2500,
      winText: ['Giỏi! Cháu giỏi hơn cả thằng cháu ông!', 'Cầm Huy Hiệu Ổ Cắm này. Nhớ đừng chọc tay vào.'],
      loseText: ['Cháu bị điện giật rồi. Về nghỉ đi.'],
      badge: '🔌',
    },
    shop: ['stickball', 'superball', 'banhmi', 'trada', 'caphe'],
    recommended: 35,
    events: [
      'Wifi mạnh quá, điện thoại bạn tự cập nhật iOS. Mất 2 tiếng.',
      'Bạn nhận được 10 thông báo "Mẹ đã thích ảnh của bạn". Ấm lòng.',
      'Bạn tìm thấy 500 Xu trong máy bán nước tự động bị kẹt!|money:500',
      'Một Que Chuột đang cắn dây cáp. Wifi giật lag. Cả tháp gào thét.',
    ],
  },
  {
    id: 'dinh',
    name: 'Đỉnh Cao Vẽ Bậy',
    emoji: '🏔️',
    bg: 'from-slate-700 via-purple-900 to-black',
    desc: ['Nơi tận cùng của thế giới giấy. Tất cả các bức tường đều bị vẽ bậy.', 'KẺ VẼ BẬY - kẻ đã tạo ra mọi Stickmon xấu xí - đang đợi bạn ở đỉnh. Cùng với... Thằng Tí?!'],
    wild: [
      { speciesId: 'queset', min: 33, max: 36, weight: 2 },
      { speciesId: 'quengau', min: 33, max: 36, weight: 2 },
      { speciesId: 'quecobap', min: 33, max: 36, weight: 2 },
      { speciesId: 'quema', min: 33, max: 36, weight: 2 },
      { speciesId: 'queluoi', min: 33, max: 36, weight: 1 },
      { speciesId: 'quegian', min: 30, max: 33, weight: 1 },
    ],
    trainer: {
      name: 'Kẻ Vẽ Bậy', title: 'Trùm Cuối - Nghệ Sĩ Tự Phong', emoji: '🎨',
      intro: ['Cuối cùng ngươi cũng đến... Ta là KẺ VẼ BẬY!', 'Chính ta đã vẽ mọi Stickmon trong thế giới này. Bằng tay trái. Nhắm mắt.', 'Ngươi dám chê hình vẽ của ta xấu? Hãy nếm sức mạnh của tác phẩm HOÀN HẢO nhất của ta!', '(Đằng sau, Thằng Tí đang cầm hộp bút màu và gật gù.)'],
      party: [{ speciesId: 'STARTER_COUNTER_FINAL', level: 38 }, { speciesId: 'quengau', level: 38 }, { speciesId: 'queset', level: 39 }, { speciesId: 'queboss', level: 42 }],
      reward: 9999,
      winText: ['KHÔNG THỂ NÀO! Tác phẩm của ta...', '...Được rồi. Ta thừa nhận. Ta vẽ xấu thật.', 'Từ nay ta sẽ đi học vẽ tử tế. Thằng Tí, đi về thôi con.', 'Tí: "Dạ bố."', '...BỐ?!'],
      loseText: ['Hahaha! Nghệ thuật của ta là bất khả chiến bại!', 'Về luyện thêm rồi lên đây, ta không đi đâu cả. Ta không có việc làm.'],
      badge: '👑',
    },
    shop: ['stickball', 'superball', 'banhmi', 'trada', 'caphe'],
    recommended: 40,
    events: [
      'Trên tường có vẽ: "Tí ❤️ Tũn". Chuyện tình bí ẩn.',
      'Bạn thấy một bức tranh vẽ chính bạn. Xấu kinh khủng. Nhưng cũng... khá giống.',
      'Bạn tìm thấy Trà Đá Đặc Biệt dưới một tảng đá!|trada',
      'Gió trên đỉnh thổi mạnh. Bạn là que. Bạn suýt bay mất.',
    ],
  },
];
