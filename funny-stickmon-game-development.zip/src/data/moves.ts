import type { StickType } from './types';

export type MoveEffect =
  | { kind: 'heal'; pct: number }
  | { kind: 'buffAtk'; stages: number }
  | { kind: 'buffDef'; stages: number }
  | { kind: 'debuffAtk'; stages: number }
  | { kind: 'debuffDef'; stages: number }
  | { kind: 'recoil'; pct: number };

export interface Move {
  id: string;
  name: string;
  type: StickType;
  power: number; // 0 = status move
  accuracy: number; // 0-100
  desc: string;
  effect?: MoveEffect;
  flavor?: string[]; // funny lines when used
}

export const MOVES: Record<string, Move> = {
  // ===== MEME =====
  culet: { id: 'culet', name: 'Cù Lét', type: 'Meme', power: 30, accuracy: 100, desc: 'Cù nách đối thủ. Cười xỉu.', flavor: ['Hihi... haha... HAHAHA!'] },
  hucdau: { id: 'hucdau', name: 'Húc Đầu', type: 'Meme', power: 45, accuracy: 100, desc: 'Húc bằng cái đầu tròn vo.', flavor: ['CỐP! Nghe như dừa rơi.'] },
  chuithe: { id: 'chuithe', name: 'Chửi Thề', type: 'Meme', power: 0, accuracy: 100, desc: 'Nói lời cay đắng. Giảm PHÒNG THỦ đối thủ.', effect: { kind: 'debuffDef', stages: 1 }, flavor: ['"Mày vẽ xấu như ba mày!"', '"Đồ que củi rẻ tiền!"'] },
  tusuong: { id: 'tusuong', name: 'Tự Sướng', type: 'Meme', power: 0, accuracy: 100, desc: 'Chụp selfie tự tin. Hồi 40% HP.', effect: { kind: 'heal', pct: 40 }, flavor: ['Chụp 47 tấm mới ưng 1 tấm.'] },
  memebungno: { id: 'memebungno', name: 'Meme Bùng Nổ', type: 'Meme', power: 85, accuracy: 90, desc: 'Ném một meme cực mặn.', flavor: ['Meme này ai cũng đã thấy trên Facebook mẹ mình.'] },
  namngu: { id: 'namngu', name: 'Nằm Ngủ', type: 'Meme', power: 0, accuracy: 100, desc: 'Ngủ tại chỗ. Hồi 50% HP.', effect: { kind: 'heal', pct: 50 }, flavor: ['Zzz... 5 phút nữa thôi mẹ...'] },
  canhe: { id: 'canhe', name: 'Cắn Nhẹ', type: 'Meme', power: 40, accuracy: 100, desc: 'Cắn. Nhẹ. Thôi.', flavor: ['Nhẹ mà đau á!'] },
  nhaydance: { id: 'nhaydance', name: 'Nhảy TikTok', type: 'Meme', power: 60, accuracy: 95, desc: 'Nhảy điệu trend. Đối thủ đau mắt.', flavor: ['Cả sân đấu cringe theo.'] },
  // ===== LỬA =====
  dotvia: { id: 'dotvia', name: 'Đốt Vía', type: 'Lửa', power: 40, accuracy: 100, desc: 'Đốt giấy xua đen đủi. Kèm đối thủ.', flavor: ['Vía đi đâu thì đi!'] },
  hoithocay: { id: 'hoithocay', name: 'Hơi Thở Cay', type: 'Lửa', power: 65, accuracy: 100, desc: 'Vừa ăn 10 trái ớt xong.', flavor: ['Cay xè! Đối thủ chảy nước mắt.'] },
  phonghoa: { id: 'phonghoa', name: 'Phóng Hỏa', type: 'Lửa', power: 90, accuracy: 85, desc: 'Phóng lửa lớn. Không được làm ở nhà.', flavor: ['Cháy rồi! Gọi 114!'] },
  luatrai: { id: 'luatrai', name: 'Lửa Trại', type: 'Lửa', power: 0, accuracy: 100, desc: 'Nướng khoai, tăng TẤN CÔNG.', effect: { kind: 'buffAtk', stages: 1 }, flavor: ['Khoai nướng ngon quá, sung lên hẳn!'] },
  nodiem: { id: 'nodiem', name: 'Nổ Hộp Diêm', type: 'Lửa', power: 120, accuracy: 80, desc: 'Cháy cả hộp diêm. Tự đau 25%.', effect: { kind: 'recoil', pct: 25 }, flavor: ['BÙM! Rát quá!'] },
  // ===== NƯỚC =====
  tatnuoc: { id: 'tatnuoc', name: 'Tạt Nước', type: 'Nước', power: 40, accuracy: 100, desc: 'Tạt như tạt người yêu cũ.', flavor: ['Ướt nhẹp!'] },
  tedam: { id: 'tedam', name: 'Tè Dầm', type: 'Nước', power: 55, accuracy: 100, desc: 'Ơ... không cố ý đâu.', flavor: ['Ơ kìa... ai làm đấy?', 'Mùi hơi khai.'] },
  songthanmini: { id: 'songthanmini', name: 'Sóng Thần Mini', type: 'Nước', power: 90, accuracy: 85, desc: 'Sóng thần cỡ chậu rửa mặt.', flavor: ['ÀO ÀO ÀO (cỡ nhỏ)!'] },
  uongtrada: { id: 'uongtrada', name: 'Uống Trà Đá', type: 'Nước', power: 0, accuracy: 100, desc: 'Trà đá vỉa hè 3k. Hồi 40% HP.', effect: { kind: 'heal', pct: 40 }, flavor: ['Mát lạnh cả tâm hồn!'] },
  xitnuoc: { id: 'xitnuoc', name: 'Xịt Vòi Sen', type: 'Nước', power: 70, accuracy: 95, desc: 'Nước lạnh buổi sáng mùa đông.', flavor: ['LẠNH QUÁ MÁ ƠIIII!'] },
  // ===== CỎ =====
  nemla: { id: 'nemla', name: 'Ném Lá', type: 'Cỏ', power: 40, accuracy: 100, desc: 'Ném lá khô, hơi xước.', flavor: ['Xoẹt xoẹt!'] },
  requan: { id: 'requan', name: 'Rễ Quấn', type: 'Cỏ', power: 60, accuracy: 100, desc: 'Quấn chặt như dây sạc trong túi.', flavor: ['Gỡ mãi không ra!'] },
  codaimoc: { id: 'codaimoc', name: 'Cỏ Dại Mọc', type: 'Cỏ', power: 90, accuracy: 85, desc: 'Cỏ mọc như tiền điện cuối tháng.', flavor: ['Mọc um tùm!'] },
  quanghop: { id: 'quanghop', name: 'Quang Hợp', type: 'Cỏ', power: 0, accuracy: 100, desc: 'Phơi nắng. Hồi 50% HP.', effect: { kind: 'heal', pct: 50 }, flavor: ['Vitamin D dồi dào!'] },
  nemdua: { id: 'nemdua', name: 'Ném Dừa', type: 'Cỏ', power: 75, accuracy: 90, desc: 'Ném dừa từ trên cây xuống.', flavor: ['CỐP! Đúng đỉnh đầu!'] },
  // ===== ĐIỆN =====
  giatnhe: { id: 'giatnhe', name: 'Giật Nhẹ', type: 'Điện', power: 40, accuracy: 100, desc: 'Như sờ tay nắm cửa mùa hanh.', flavor: ['Tách! Tê tê.'] },
  chamodien: { id: 'chamodien', name: 'Chạm Ổ Điện', type: 'Điện', power: 65, accuracy: 100, desc: 'Mẹ đã dặn rồi mà không nghe.', flavor: ['Tóc dựng đứng luôn!'] },
  setdanh: { id: 'setdanh', name: 'Sét Đánh Ngang Tai', type: 'Điện', power: 100, accuracy: 70, desc: 'Sét lớn nhưng hay trượt.', flavor: ['ĐOÀNG!!!'] },
  sacpin: { id: 'sacpin', name: 'Sạc Pin', type: 'Điện', power: 0, accuracy: 100, desc: 'Cắm sạc. Tăng TẤN CÔNG.', effect: { kind: 'buffAtk', stages: 1 }, flavor: ['100% pin! Sung mãn!'] },
  matwifi: { id: 'matwifi', name: 'Ngắt Wifi', type: 'Điện', power: 0, accuracy: 100, desc: 'Ngắt wifi đối thủ. Giảm TẤN CÔNG.', effect: { kind: 'debuffAtk', stages: 1 }, flavor: ['Đối thủ mất tinh thần vì không có mạng.'] },
  // ===== MA =====
  hudoa: { id: 'hudoa', name: 'Hù Dọa', type: 'Ma', power: 0, accuracy: 100, desc: 'HÙ! Giảm TẤN CÔNG đối thủ.', effect: { kind: 'debuffAtk', stages: 1 }, flavor: ['HÙUUU! Đối thủ giật mình rơi dép.'] },
  bongde: { id: 'bongde', name: 'Bóng Đè', type: 'Ma', power: 60, accuracy: 100, desc: 'Đè lúc 3 giờ sáng.', flavor: ['Không cựa quậy được!'] },
  amanhdeadline: { id: 'amanhdeadline', name: 'Ám Ảnh Deadline', type: 'Ma', power: 90, accuracy: 90, desc: 'Nhắc deadline ngày mai. Cực đau.', flavor: ['"Mai nộp bài nhé!" - đối thủ tái mặt.'] },
  hutvia: { id: 'hutvia', name: 'Hút Vía', type: 'Ma', power: 50, accuracy: 100, desc: 'Hút vía đối thủ, hồi 25% HP.', effect: { kind: 'heal', pct: 25 }, flavor: ['Ngon, vía đối thủ hơi mặn.'] },
  // ===== ĐẤM =====
  tatyeu: { id: 'tatyeu', name: 'Tát Yêu', type: 'Đấm', power: 40, accuracy: 100, desc: 'Tát nhưng bằng tình thương.', flavor: ['BỐP! (yêu thương)'] },
  daxoay: { id: 'daxoay', name: 'Đá Xoáy', type: 'Đấm', power: 65, accuracy: 95, desc: 'Xoáy 720 độ rồi đá.', flavor: ['Xoay xoay xoay... ĐÁ!'] },
  gongco: { id: 'gongco', name: 'Gồng Cơ', type: 'Đấm', power: 0, accuracy: 100, desc: 'Gồng lên nhìn to. Tăng TẤN CÔNG.', effect: { kind: 'buffAtk', stages: 1 }, flavor: ['Cơ bắp phồng lên 2mm!'] },
  dampchetluon: { id: 'dampchetluon', name: 'Đấm Phát Chết Luôn', type: 'Đấm', power: 130, accuracy: 55, desc: 'Nghe tên là hiểu. Nhưng hay trượt.', flavor: ['MỘT ĐẤM!!!'] },
  ganggang: { id: 'ganggang', name: 'Gánh Team', type: 'Đấm', power: 0, accuracy: 100, desc: 'Gánh cả team. Tăng PHÒNG THỦ.', effect: { kind: 'buffDef', stages: 1 }, flavor: ['Vai to gánh nặng!'] },
};
