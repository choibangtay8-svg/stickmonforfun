import { MOVES } from '../data/moves';
import { ITEMS, type Inventory, type ItemId } from '../data/items';
import { SPECIES } from '../data/stickmon';
import {
  type MonInstance, calcDamage, xpGain, applyXp, catchChance, enemyChooseMove,
  effText, missText, critText, pick, resetBattleState,
} from './logic';

export interface BattleState {
  party: MonInstance[];
  activeIdx: number;
  enemyParty: MonInstance[];
  enemyIdx: number;
  isTrainer: boolean;
  trainerName?: string;
  inventory: Inventory;
  outcome?: 'win' | 'lose' | 'run' | 'caught';
  caught?: MonInstance;
  needSwitch?: boolean;
  runAttempts: number;
  moneyBonus: number;
}

export type Anim = { who: 'player' | 'enemy'; kind: 'attack' | 'hit' | 'faint' | 'ball' | 'heal' | 'enter' | 'levelup' };
export interface Step { text: string; state: BattleState; anim?: Anim }

export type PlayerAction =
  | { type: 'move'; moveId: string }
  | { type: 'item'; itemId: ItemId; targetIdx: number }
  | { type: 'switch'; idx: number }
  | { type: 'run' };

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

const enterLines = ['Lên đi {n}! Tin ở mày!', 'Ra trận thôi {n}! Đừng làm tao thất vọng!', '{n}, tới lượt mày tỏa sáng!', 'Đi {n}! Xử đẹp nó!'];
const faintLines = ['{n} đã ngất xỉu! Nằm luôn.', '{n} không chịu nổi nữa! Ngất.', '{n} đã gục. Ngủ ngon nhé.', '{n} ngã cái rầm. Hết phim.'];

class Engine {
  steps: Step[] = [];
  constructor(public s: BattleState) {}

  push(text: string, anim?: Anim) {
    this.steps.push({ text, state: clone(this.s), anim });
  }
  get me() { return this.s.party[this.s.activeIdx]; }
  get foe() { return this.s.enemyParty[this.s.enemyIdx]; }
  name(m: MonInstance, side: 'player' | 'enemy') {
    const n = SPECIES[m.speciesId].name;
    return side === 'enemy' ? (this.s.isTrainer ? `${n} của đối thủ` : `${n} hoang dã`) : n;
  }

  executeMove(side: 'player' | 'enemy', moveId: string): boolean {
    const attacker = side === 'player' ? this.me : this.foe;
    const defender = side === 'player' ? this.foe : this.me;
    const other = side === 'player' ? 'enemy' : 'player';
    if (attacker.hp <= 0) return false;
    const mv = MOVES[moveId];
    this.push(`${this.name(attacker, side)} dùng ${mv.name}!`, { who: side, kind: 'attack' });
    if (mv.flavor && Math.random() < 0.6) this.push(pick(mv.flavor));

    if (Math.random() * 100 > mv.accuracy) {
      this.push(missText());
      return false;
    }

    if (mv.power > 0) {
      const { dmg, eff, crit } = calcDamage(attacker, defender, moveId);
      if (eff === 0) {
        this.push(effText(0));
        return false;
      }
      let newHp = Math.max(0, defender.hp - dmg);
      let gianSaved = false;
      if (newHp === 0 && SPECIES[defender.speciesId].ability === 'gian' && !defender.usedGian) {
        newHp = 1;
        defender.usedGian = true;
        gianSaved = true;
      }
      defender.hp = newHp;
      this.push(`${this.name(defender, other)} mất ${dmg} HP!`, { who: other, kind: 'hit' });
      if (crit) this.push(critText());
      const et = effText(eff);
      if (et) this.push(et);
      if (gianSaved) this.push(`${SPECIES[defender.speciesId].name} KHÔNG THỂ CHẾT! Nó sống sót với 1 HP. Gián mà!`);
      if (mv.effect?.kind === 'recoil') {
        const rec = Math.max(1, Math.floor(dmg * mv.effect.pct / 100));
        attacker.hp = Math.max(1, attacker.hp - rec);
        this.push(`${this.name(attacker, side)} tự làm đau mình ${rec} HP! Ngu ghê.`, { who: side, kind: 'hit' });
      }
      if (mv.effect?.kind === 'heal') {
        const h = Math.max(1, Math.floor(dmg * mv.effect.pct / 100));
        attacker.hp = Math.min(attacker.maxHp, attacker.hp + h);
        this.push(`${this.name(attacker, side)} hồi ${h} HP!`, { who: side, kind: 'heal' });
      }
      return defender.hp === 0;
    }

    // status move
    const ef = mv.effect;
    if (!ef) return false;
    if (ef.kind === 'heal') {
      if (attacker.hp >= attacker.maxHp) { this.push('Nhưng HP đã đầy rồi! Phí một lượt.'); return false; }
      const h = Math.floor(attacker.maxHp * ef.pct / 100);
      attacker.hp = Math.min(attacker.maxHp, attacker.hp + h);
      this.push(`${this.name(attacker, side)} hồi ${h} HP!`, { who: side, kind: 'heal' });
    } else if (ef.kind === 'buffAtk') {
      if (attacker.atkStage >= 4) { this.push('TẤN CÔNG đã max rồi! Gồng nữa là nổ.'); return false; }
      attacker.atkStage += ef.stages;
      this.push(`TẤN CÔNG của ${this.name(attacker, side)} tăng lên!`, { who: side, kind: 'heal' });
    } else if (ef.kind === 'buffDef') {
      if (attacker.defStage >= 4) { this.push('PHÒNG THỦ đã max rồi!'); return false; }
      attacker.defStage += ef.stages;
      this.push(`PHÒNG THỦ của ${this.name(attacker, side)} tăng lên!`, { who: side, kind: 'heal' });
    } else if (ef.kind === 'debuffAtk') {
      if (defender.atkStage <= -4) { this.push('TẤN CÔNG đối thủ không thể giảm thêm! Nó đã quá yếu.'); return false; }
      defender.atkStage -= ef.stages;
      this.push(`TẤN CÔNG của ${this.name(defender, other)} giảm xuống!`, { who: other, kind: 'hit' });
    } else if (ef.kind === 'debuffDef') {
      if (defender.defStage <= -4) { this.push('PHÒNG THỦ đối thủ không thể giảm thêm!'); return false; }
      defender.defStage -= ef.stages;
      this.push(`PHÒNG THỦ của ${this.name(defender, other)} giảm xuống!`, { who: other, kind: 'hit' });
    }
    return false;
  }

  /** Handles enemy faint: xp, next enemy or win. Returns true if battle over */
  handleEnemyFaint(): boolean {
    const foe = this.foe;
    this.push(pick(faintLines).replace('{n}', this.name(foe, 'enemy')), { who: 'enemy', kind: 'faint' });
    const gained = xpGain(foe, this.s.isTrainer);
    // XP to active + half to others alive
    this.s.party.forEach((m, i) => {
      if (m.hp <= 0) return;
      const amt = i === this.s.activeIdx ? gained : Math.floor(gained / 2);
      if (amt <= 0) return;
      const before = m.level;
      const res = applyXp(m, amt);
      this.s.party[i] = res.mon;
      if (i === this.s.activeIdx) this.push(`${SPECIES[m.speciesId].name} nhận được ${amt} XP!`);
      for (const msg of res.messages) {
        this.push(msg, res.mon.level > before && i === this.s.activeIdx ? { who: 'player', kind: 'levelup' } : undefined);
      }
    });
    // next enemy?
    const nextIdx = this.s.enemyParty.findIndex((m, i) => i !== this.s.enemyIdx && m.hp > 0);
    if (this.s.isTrainer && nextIdx >= 0) {
      this.s.enemyIdx = nextIdx;
      this.s.enemyParty[nextIdx] = resetBattleState(this.s.enemyParty[nextIdx]);
      this.push(`${this.s.trainerName} tung ra ${SPECIES[this.foe.speciesId].name}!`, { who: 'enemy', kind: 'enter' });
      return false;
    }
    this.s.outcome = 'win';
    return true;
  }

  handlePlayerFaint(): boolean {
    const me = this.me;
    this.push(pick(faintLines).replace('{n}', SPECIES[me.speciesId].name), { who: 'player', kind: 'faint' });
    const alive = this.s.party.some((m) => m.hp > 0);
    if (alive) {
      this.s.needSwitch = true;
      return true;
    }
    this.s.outcome = 'lose';
    this.push('Bạn hết Stickmon để đấu! Mắt tối sầm lại...');
    return true;
  }

  enemyTurn(): boolean {
    if (this.foe.hp <= 0 || this.me.hp <= 0) return false;
    const mid = enemyChooseMove(this.foe, this.me);
    const ko = this.executeMove('enemy', mid);
    if (ko) { this.handlePlayerFaint(); return true; }
    if (this.foe.hp <= 0) { return this.handleEnemyFaint(); }
    return false;
  }

  playerMoveTurn(moveId: string): boolean {
    const ko = this.executeMove('player', moveId);
    if (ko) return this.handleEnemyFaint();
    if (this.me.hp <= 0) { this.handlePlayerFaint(); return true; }
    return false;
  }

  run(action: PlayerAction) {
    this.s.needSwitch = false;
    switch (action.type) {
      case 'move': {
        const pSpd = this.me.spd, eSpd = this.foe.spd;
        const playerFirst = pSpd > eSpd || (pSpd === eSpd && Math.random() < 0.5);
        if (playerFirst) {
          if (this.playerMoveTurn(action.moveId)) break;
          this.enemyTurn();
        } else {
          if (this.enemyTurn()) break;
          this.playerMoveTurn(action.moveId);
        }
        break;
      }
      case 'switch': {
        const old = SPECIES[this.me.speciesId].name;
        this.s.party[this.s.activeIdx] = resetBattleState(this.me);
        this.s.activeIdx = action.idx;
        this.push(`${old}, về nghỉ đi! ${pick(enterLines).replace('{n}', SPECIES[this.me.speciesId].name)}`, { who: 'player', kind: 'enter' });
        this.enemyTurn();
        break;
      }
      case 'item': {
        const item = ITEMS[action.itemId];
        const count = this.s.inventory[action.itemId] ?? 0;
        if (count <= 0) { this.push('Bạn không có món này! Đừng có xạo.'); break; }
        if (item.kind === 'ball') {
          if (this.s.isTrainer) { this.push(`${this.s.trainerName}: "Ê! Ăn cắp Stickmon người khác là phạm pháp đó nha!"`); break; }
          this.s.inventory[action.itemId] = count - 1;
          this.push(`Bạn ném ${item.name}!`, { who: 'enemy', kind: 'ball' });
          const chance = catchChance(this.foe, item.value);
          const shakes = Math.random() < chance ? 3 : Math.floor(Math.random() * 3);
          const shakeTexts = ['Lắc...', 'Lắc lắc...', 'Lắc lắc lắc...'];
          for (let i = 0; i < shakes; i++) this.push(shakeTexts[i], { who: 'enemy', kind: 'ball' });
          if (shakes === 3) {
            this.push(`🎉 BẮT ĐƯỢC ${SPECIES[this.foe.speciesId].name}! Nó đã gia nhập băng đảng của bạn!`, { who: 'enemy', kind: 'ball' });
            this.s.caught = resetBattleState({ ...this.foe });
            this.s.outcome = 'caught';
            if (this.s.party.length < 6) {
              this.s.party.push(this.s.caught);
            } else {
              this.push('Nhưng đội đã đầy 6 con! Nó được gửi về Giáo sư Cây Que (ông ấy sẽ chăm nó... chắc vậy).');
            }
            break;
          }
          this.push(pick(['Ôi không! Nó thoát ra rồi!', 'Xém tí nữa! Nó bật ra như lò xo!', 'Nó thoát ra và còn nhìn bạn khinh bỉ.', 'Trượt! Nó cười vào mặt bạn.']), { who: 'enemy', kind: 'enter' });
          this.enemyTurn();
          break;
        }
        const target = this.s.party[action.targetIdx];
        const tName = SPECIES[target.speciesId].name;
        if (item.kind === 'heal') {
          if (target.hp <= 0) { this.push(`${tName} đã ngất rồi, cho ăn cũng không nuốt được!`); break; }
          if (target.hp >= target.maxHp) { this.push(`${tName} đang no rồi, HP đầy!`); break; }
          this.s.inventory[action.itemId] = count - 1;
          const h = Math.min(item.value, target.maxHp - target.hp);
          target.hp += h;
          this.push(`${tName} dùng ${item.name} và hồi ${h} HP! Ngon!`, { who: 'player', kind: 'heal' });
        } else if (item.kind === 'revive') {
          if (target.hp > 0) { this.push(`${tName} chưa ngất! Uống cà phê giờ mất ngủ đấy.`); break; }
          this.s.inventory[action.itemId] = count - 1;
          target.hp = Math.floor(target.maxHp * item.value / 100);
          this.push(`${tName} ngửi mùi cà phê và bật dậy! Hồi ${target.hp} HP!`, { who: 'player', kind: 'heal' });
        }
        this.enemyTurn();
        break;
      }
      case 'run': {
        if (this.s.isTrainer) {
          this.push(`${this.s.trainerName}: "Chạy đi đâu?! Đánh chưa xong mà!"`);
          break;
        }
        this.s.runAttempts += 1;
        const chance = Math.min(0.95, 0.4 + (this.me.spd - this.foe.spd) / 100 + this.s.runAttempts * 0.15);
        if (Math.random() < chance) {
          this.push(pick(['Bạn chạy thoát an toàn! Chân que mà nhanh phết.', 'Chạy thoát! Đối thủ đuổi theo nhưng vấp cục đá.', 'Chuồn êm! Không ai thấy gì.']));
          this.s.outcome = 'run';
        } else {
          this.push(pick(['Không thoát được! Bị túm gáy!', 'Chạy không kịp! Chân ngắn quá.', 'Trượt chân! Nằm sấp mặt.']));
          this.enemyTurn();
        }
        break;
      }
    }
    return this.steps;
  }

  forceSwitch(idx: number) {
    this.s.needSwitch = false;
    this.s.activeIdx = idx;
    this.push(pick(enterLines).replace('{n}', SPECIES[this.me.speciesId].name), { who: 'player', kind: 'enter' });
    return this.steps;
  }
}

export function runTurn(state: BattleState, action: PlayerAction): Step[] {
  const eng = new Engine(clone(state));
  return eng.run(action);
}

export function runForceSwitch(state: BattleState, idx: number): Step[] {
  const eng = new Engine(clone(state));
  return eng.forceSwitch(idx);
}
