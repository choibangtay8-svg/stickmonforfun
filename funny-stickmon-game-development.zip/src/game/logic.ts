import { SPECIES, type Species } from '../data/stickmon';
import { MOVES } from '../data/moves';
import { effectiveness } from '../data/types';

export interface MonInstance {
  uid: string;
  speciesId: string;
  level: number;
  xp: number;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  moves: string[];
  atkStage: number;
  defStage: number;
  usedGian?: boolean;
}

let uidCounter = 0;
export const newUid = () => `${Date.now().toString(36)}-${(uidCounter++).toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

export const xpForLevel = (lv: number) => Math.floor(Math.pow(lv, 3) * 0.8);

export function calcStats(species: Species, level: number) {
  return {
    maxHp: Math.floor((species.base.hp * 2 * level) / 100) + level + 10,
    atk: Math.floor((species.base.atk * 2 * level) / 100) + 5,
    def: Math.floor((species.base.def * 2 * level) / 100) + 5,
    spd: Math.floor((species.base.spd * 2 * level) / 100) + 5,
  };
}

export function movesAtLevel(species: Species, level: number): string[] {
  const learned = species.learnset.filter((l) => l.level <= level).map((l) => l.move);
  const unique = Array.from(new Set(learned));
  return unique.slice(-4);
}

export function createMon(speciesId: string, level: number): MonInstance {
  const sp = SPECIES[speciesId];
  const stats = calcStats(sp, level);
  return {
    uid: newUid(),
    speciesId,
    level,
    xp: xpForLevel(level),
    hp: stats.maxHp,
    ...stats,
    moves: movesAtLevel(sp, level),
    atkStage: 0,
    defStage: 0,
  };
}

export const speciesOf = (m: MonInstance) => SPECIES[m.speciesId];

export function stageMult(stage: number) {
  const s = Math.max(-4, Math.min(4, stage));
  return s >= 0 ? (2 + s) / 2 : 2 / (2 - s);
}

export function calcDamage(attacker: MonInstance, defender: MonInstance, moveId: string) {
  const move = MOVES[moveId];
  const aSp = speciesOf(attacker);
  const dSp = speciesOf(defender);
  const atk = attacker.atk * stageMult(attacker.atkStage);
  const def = defender.def * stageMult(defender.defStage);
  const stab = aSp.type === move.type ? 1.5 : 1;
  const eff = effectiveness(move.type, dSp.type);
  const crit = Math.random() < 0.0625 ? 1.5 : 1;
  const rand = 0.85 + Math.random() * 0.15;
  const base = ((2 * attacker.level) / 5 + 2) * move.power * (atk / def) / 50 + 2;
  const dmg = Math.max(1, Math.floor(base * stab * eff * crit * rand));
  return { dmg: eff === 0 ? 0 : dmg, eff, crit: crit > 1 };
}

export function xpGain(defeated: MonInstance, isTrainer: boolean) {
  const sp = speciesOf(defeated);
  return Math.floor((sp.baseXp * defeated.level) / 5 * (isTrainer ? 1.5 : 1));
}

export function catchChance(target: MonInstance, ballMult: number) {
  const sp = speciesOf(target);
  const hpFactor = (3 * target.maxHp - 2 * target.hp) / (3 * target.maxHp);
  const a = (sp.catchRate * ballMult * hpFactor) / 255;
  return Math.min(1, a * 1.3);
}

export function healMon(m: MonInstance): MonInstance {
  return { ...m, hp: m.maxHp, atkStage: 0, defStage: 0, usedGian: false };
}

export function resetBattleState(m: MonInstance): MonInstance {
  return { ...m, atkStage: 0, defStage: 0, usedGian: false };
}

/** Apply level up; returns messages & mutated mon */
export function applyXp(mon: MonInstance, amount: number): { mon: MonInstance; messages: string[]; newMoves: string[]; evolvedTo?: string } {
  let m = { ...mon, xp: mon.xp + amount };
  const messages: string[] = [];
  const newMoves: string[] = [];
  let evolvedTo: string | undefined;
  while (m.level < 60 && m.xp >= xpForLevel(m.level + 1)) {
    m.level += 1;
    const sp = speciesOf(m);
    const old = { maxHp: m.maxHp, atk: m.atk, def: m.def, spd: m.spd };
    const st = calcStats(sp, m.level);
    const hpGain = st.maxHp - old.maxHp;
    m = { ...m, ...st, hp: Math.min(st.maxHp, m.hp + hpGain) };
    messages.push(`${sp.name} lên cấp ${m.level}! (+${hpGain} HP, +${st.atk - old.atk} ATK, +${st.def - old.def} DEF, +${st.spd - old.spd} SPD)`);
    for (const l of sp.learnset) {
      if (l.level === m.level && !m.moves.includes(l.move)) {
        if (m.moves.length < 4) {
          m.moves = [...m.moves, l.move];
          messages.push(`${sp.name} học được chiêu ${MOVES[l.move].name}!`);
        } else {
          const forgotten = m.moves[0];
          m.moves = [...m.moves.slice(1), l.move];
          messages.push(`${sp.name} quên ${MOVES[forgotten].name} để học ${MOVES[l.move].name}! (Não que nhỏ lắm)`);
        }
        newMoves.push(l.move);
      }
    }
    if (sp.evolve && m.level >= sp.evolve.level) {
      const into = SPECIES[sp.evolve.into];
      const st2 = calcStats(into, m.level);
      const ratio = m.hp / m.maxHp;
      m = { ...m, speciesId: into.id, ...st2, hp: Math.max(1, Math.floor(st2.maxHp * ratio)) };
      messages.push(`✨ CÁI GÌ?! ${sp.name} đang tiến hóa... thành ${into.name}! ✨`);
      evolvedTo = into.id;
    }
  }
  return { mon: m, messages, newMoves, evolvedTo };
}

export function pickWild(entries: { speciesId: string; min: number; max: number; weight: number }[]) {
  const total = entries.reduce((s, e) => s + e.weight, 0);
  let r = Math.random() * total;
  for (const e of entries) {
    r -= e.weight;
    if (r <= 0) return createMon(e.speciesId, e.min + Math.floor(Math.random() * (e.max - e.min + 1)));
  }
  const e = entries[0];
  return createMon(e.speciesId, e.min);
}

export function enemyChooseMove(enemy: MonInstance, target: MonInstance): string {
  const scored = enemy.moves.map((id) => {
    const mv = MOVES[id];
    let score = Math.random() * 30;
    if (mv.power > 0) {
      score += mv.power * effectiveness(mv.type, speciesOf(target).type) * (mv.type === speciesOf(enemy).type ? 1.3 : 1) * (mv.accuracy / 100);
    } else if (mv.effect?.kind === 'heal') {
      score += enemy.hp / enemy.maxHp < 0.4 ? 120 : 5;
    } else {
      score += enemy.hp / enemy.maxHp > 0.7 && Math.random() < 0.4 ? 60 : 10;
    }
    return { id, score };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored[0].id;
}

export const effText = (eff: number) => {
  if (eff === 0) return 'Không có tác dụng gì cả! Như nói chuyện với người yêu cũ.';
  if (eff >= 2) return pick(['SIÊU HIỆU QUẢ! Đau như bị người yêu bỏ!', 'SIÊU HIỆU QUẢ! Đối thủ khóc bằng tiếng mẹ đẻ!', 'SIÊU HIỆU QUẢ! Cả làng nghe tiếng thét!']);
  if (eff < 1) return pick(['Không hiệu quả lắm. Như gãi ngứa.', 'Không hiệu quả lắm. Đối thủ ngáp.', 'Không hiệu quả lắm. Hơi nhột thôi.']);
  return '';
};

export const missText = () => pick(['Hụt! Trượt như deadline!', 'Hụt! Ném đâu không biết!', 'Hụt! Đối thủ né kiểu Matrix!', 'Hụt! Mắt kém rồi.']);
export const critText = () => pick(['CHÍ MẠNG! Trúng chỗ hiểm!', 'CHÍ MẠNG! Đau thấu tim gan!', 'CHÍ MẠNG! Quá mạnh, quá nguy hiểm!']);

export function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
