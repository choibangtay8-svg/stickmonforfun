import { useCallback, useEffect, useMemo, useState } from 'react';
import { STAGES } from './data/stages';
import { ITEMS, type Inventory, type ItemId } from './data/items';
import { type MonInstance, createMon, healMon, pickWild, pick, resetBattleState } from './game/logic';
import type { BattleState } from './game/battle';
import Battle from './components/Battle';
import Hub from './components/Hub';
import { TitleScreen, IntroScreen, ShopScreen, PartyScreen, DexScreen, EndingScreen, DialogSequence } from './components/screens';
import { Button, DialogBox } from './components/ui';

interface GameState {
  name: string;
  starter: string;
  party: MonInstance[];
  box: MonInstance[];
  inventory: Inventory;
  money: number;
  stageIdx: number;
  badges: string[];
  beaten: string[];
  seen: string[];
  caught: string[];
  battles: number;
  finished: boolean;
}

type Screen =
  | { k: 'title' }
  | { k: 'intro' }
  | { k: 'hub' }
  | { k: 'battle'; bs: BattleState; emoji?: string; kind: 'wild' | 'trainer' }
  | { k: 'trainerIntro' }
  | { k: 'trainerOutro'; won: boolean }
  | { k: 'shop' }
  | { k: 'party' }
  | { k: 'dex' }
  | { k: 'center' }
  | { k: 'message'; text: string; speaker?: string }
  | { k: 'ending' };

const SAVE_KEY = 'stickmon-save-v1';
const COUNTER: Record<string, string> = { quelua: 'quenuoc', quenuoc: 'queco', queco: 'quelua' };
const COUNTER_FINAL: Record<string, string> = { quelua: 'quethuyquai', quenuoc: 'quecothu', queco: 'quediemrong' };

const NURSE_LINES = [
  'Chào mừng đến Trung Tâm Stickmon! Đội của bạn đã hồi phục hoàn toàn. Miễn phí, vì chúng tôi không có giấy phép thu tiền.',
  'Xong! Tôi đã dán băng keo lại chỗ rách. Đẹp như mới. Gần như.',
  'Đội bạn khỏe rồi! Tôi đã tô lại mấy chỗ bị nhòe. Đừng cho chúng nghịch nước nữa.',
  'Hồi phục hoàn tất! Con Que Gián của ai đó vừa cắn tôi. Không sao. Tôi quen rồi.',
  'Đã chữa lành! Tiện thể, chúng tôi có bán thẻ thành viên. Không có lợi ích gì cả, chỉ để tôi đủ KPI.',
];

function loadSave(): GameState | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? (JSON.parse(raw) as GameState) : null;
  } catch { return null; }
}

export default function App() {
  const [game, setGame] = useState<GameState | null>(null);
  const [screen, setScreen] = useState<Screen>({ k: 'title' });
  const hasSave = useMemo(() => !!loadSave(), [screen.k]);

  // autosave
  useEffect(() => {
    if (game && screen.k !== 'battle') localStorage.setItem(SAVE_KEY, JSON.stringify(game));
  }, [game, screen.k]);

  const update = useCallback((fn: (g: GameState) => GameState) => setGame((g) => (g ? fn(g) : g)), []);

  const startNew = (name: string, starter: string) => {
    const g: GameState = {
      name, starter,
      party: [createMon(starter, 5)],
      box: [],
      inventory: { stickball: 5, banhmi: 2 },
      money: 500,
      stageIdx: 0,
      badges: [],
      beaten: [],
      seen: [starter],
      caught: [starter],
      battles: 0,
      finished: false,
    };
    setGame(g);
    setScreen({ k: 'hub' });
  };

  if (!game || screen.k === 'title') {
    return (
      <TitleScreen
        hasSave={hasSave}
        onNew={() => { setScreen({ k: 'intro' }); }}
        onContinue={() => { const s = loadSave(); if (s) { setGame(s); setScreen({ k: 'hub' }); } }}
      />
    );
  }
  if (screen.k === 'intro') return <IntroScreen onDone={startNew} />;

  const stage = STAGES[game.stageIdx];
  const trainerBeaten = game.beaten.includes(stage.id);

  // ===== actions =====
  const startWild = () => {
    const r = Math.random();
    if (r < 0.25) {
      // random event
      const ev = pick(stage.events);
      const [text, reward] = ev.split('|');
      if (reward) {
        if (reward.startsWith('money:')) {
          const amt = parseInt(reward.split(':')[1]);
          update((g) => ({ ...g, money: g.money + amt }));
        } else {
          const id = reward as ItemId;
          update((g) => ({ ...g, inventory: { ...g.inventory, [id]: (g.inventory[id] ?? 0) + 1 } }));
        }
      }
      setScreen({ k: 'message', text });
      return;
    }
    const alive = game.party.findIndex((m) => m.hp > 0);
    if (alive < 0) { setScreen({ k: 'message', text: 'Cả đội đang ngất! Đi Trung Tâm Stickmon trước đã, đừng liều.', speaker: 'Lương tâm' }); return; }
    const wild = pickWild(stage.wild);
    update((g) => ({ ...g, seen: g.seen.includes(wild.speciesId) ? g.seen : [...g.seen, wild.speciesId] }));
    const bs: BattleState = {
      party: game.party.map(resetBattleState), activeIdx: alive,
      enemyParty: [wild], enemyIdx: 0, isTrainer: false,
      inventory: { ...game.inventory }, runAttempts: 0, moneyBonus: 0,
    };
    setScreen({ k: 'battle', bs, kind: 'wild' });
  };

  const startTrainer = () => {
    const alive = game.party.findIndex((m) => m.hp > 0);
    if (alive < 0) { setScreen({ k: 'message', text: 'Cả đội đang ngất mà đòi thách đấu? Đi hồi phục đi bạn ơi.', speaker: 'Lương tâm' }); return; }
    const t = stage.trainer;
    const enemyParty = t.party.map((e) => {
      let sid = e.speciesId;
      if (sid === 'STARTER_COUNTER') sid = COUNTER[game.starter];
      if (sid === 'STARTER_COUNTER_FINAL') sid = COUNTER_FINAL[game.starter];
      return createMon(sid, e.level);
    });
    update((g) => ({ ...g, seen: Array.from(new Set([...g.seen, ...enemyParty.map((m) => m.speciesId)])) }));
    const bs: BattleState = {
      party: game.party.map(resetBattleState), activeIdx: alive,
      enemyParty, enemyIdx: 0, isTrainer: true, trainerName: t.name,
      inventory: { ...game.inventory }, runAttempts: 0, moneyBonus: trainerBeaten ? Math.floor(t.reward / 4) : t.reward,
    };
    setScreen({ k: 'battle', bs, kind: 'trainer', emoji: t.emoji });
  };

  const onBattleEnd = (final: BattleState, kind: 'wild' | 'trainer') => {
    const party = final.party.map(resetBattleState);
    let box = game.box;
    let money = game.money;
    let caught = game.caught;
    if (final.outcome === 'caught' && final.caught) {
      const sid = final.caught.speciesId;
      caught = caught.includes(sid) ? caught : [...caught, sid];
      if (!party.some((m) => m.uid === final.caught!.uid)) box = [...box, final.caught];
    }
    // track evolutions as caught
    for (const m of party) if (!caught.includes(m.speciesId)) caught = [...caught, m.speciesId];

    let msg: Screen | null = null;
    if (final.outcome === 'lose') {
      const lost = Math.floor(money / 2);
      money -= lost;
      msg = { k: 'message', speaker: 'Y tá', text: `Bạn tỉnh dậy ở Trung Tâm Stickmon. Đội đã hồi phục. Bạn làm rơi ${lost} Xu trên đường chạy. Ai đó đã nhặt. Không phải tôi.` };
      party.forEach((m, i) => (party[i] = healMon(m)));
    } else if (final.outcome === 'win' && kind === 'wild') {
      const bonus = final.enemyParty[0].level * 8 + Math.floor(Math.random() * 20);
      money += bonus;
      msg = { k: 'message', text: pick([`Bạn nhặt được ${bonus} Xu rơi ra từ túi con que hoang dã. Nó có túi à?`, `Con que hoang dã bỏ chạy để lại ${bonus} Xu. Và một mùi hương lạ.`, `Thắng! Bạn tìm thấy ${bonus} Xu dưới đất. Chắc của nó. Giờ của bạn.`]) };
    } else if (final.outcome === 'win' && kind === 'trainer') {
      money += final.moneyBonus;
    }

    setGame({ ...game, party, box, money, caught, inventory: final.inventory, battles: game.battles + 1 });

    if (kind === 'trainer') {
      setScreen({ k: 'trainerOutro', won: final.outcome === 'win' });
    } else {
      setScreen(msg ?? { k: 'hub' });
    }
  };

  const finishTrainerOutro = (won: boolean) => {
    if (!won) { setScreen({ k: 'message', speaker: 'Y tá', text: 'Bạn tỉnh dậy ở Trung Tâm Stickmon. Đội đã hồi phục. Bạn làm rơi một nửa số Xu trên đường chạy. Đau ví hơn đau tim.' }); return; }
    const first = !trainerBeaten;
    const isLast = game.stageIdx === STAGES.length - 1;
    update((g) => ({
      ...g,
      beaten: g.beaten.includes(stage.id) ? g.beaten : [...g.beaten, stage.id],
      badges: stage.trainer.badge && first ? [...g.badges, stage.trainer.badge] : g.badges,
      finished: g.finished || isLast,
    }));
    if (isLast && first) setScreen({ k: 'ending' });
    else if (first && stage.trainer.badge) setScreen({ k: 'message', text: `Bạn nhận được Huy Hiệu ${stage.trainer.badge} và ${stage.trainer.reward} Xu! Đường đi tiếp đã mở!` });
    else setScreen({ k: 'message', text: `Bạn nhận được ${first ? stage.trainer.reward : Math.floor(stage.trainer.reward / 4)} Xu! ${first ? 'Đường đi tiếp đã mở!' : 'Đánh lại nên ít hơn, đừng khiếu nại.'}` });
  };

  // ===== render =====
  const wrap = (child: React.ReactNode, bgClass = 'bg-gray-700') => (
    <div className={`min-h-screen ${bgClass} p-3 sm:p-6 flex items-start justify-center`}>
      <div className="w-full">{child}</div>
    </div>
  );

  switch (screen.k) {
    case 'hub':
      return wrap(
        <Hub
          stageIdx={game.stageIdx} party={game.party} money={game.money} badges={game.badges} name={game.name}
          trainerBeaten={trainerBeaten} finished={game.finished}
          onExplore={startWild}
          onChallenge={() => setScreen({ k: 'trainerIntro' })}
          onCenter={() => { update((g) => ({ ...g, party: g.party.map(healMon), box: g.box.map(healMon) })); setScreen({ k: 'center' }); }}
          onShop={() => setScreen({ k: 'shop' })}
          onParty={() => setScreen({ k: 'party' })}
          onDex={() => setScreen({ k: 'dex' })}
          onNext={() => update((g) => ({ ...g, stageIdx: Math.min(STAGES.length - 1, g.stageIdx + 1) }))}
          onPrev={() => update((g) => ({ ...g, stageIdx: Math.max(0, g.stageIdx - 1) }))}
          onQuit={() => setScreen({ k: 'title' })}
        />,
      );
    case 'battle':
      return (
        <div className="min-h-screen bg-gray-800 flex items-center justify-center">
          <div className="w-full max-w-4xl sm:my-4 sm:sketch-border overflow-hidden bg-gray-800">
            <Battle initial={screen.bs} bg={stage.bg} trainerEmoji={screen.emoji} onEnd={(f) => onBattleEnd(f, screen.kind)} />
          </div>
        </div>
      );
    case 'trainerIntro':
      return wrap(
        <div className="max-w-2xl mx-auto mt-10">
          <DialogSequence emoji={stage.trainer.emoji} speaker={`${stage.trainer.name} - ${stage.trainer.title}`} lines={trainerBeaten ? ['Lại là ngươi à? Được, đánh lại thì đánh. Ta rảnh.'] : stage.trainer.intro} onDone={startTrainer} />
          <div className="text-center mt-4"><Button className="text-sm" onClick={() => setScreen({ k: 'hub' })}>Ơ khoan, tôi chưa sẵn sàng (quay về)</Button></div>
        </div>,
        `bg-gradient-to-b ${stage.bg}`,
      );
    case 'trainerOutro':
      return wrap(
        <div className="max-w-2xl mx-auto mt-10">
          <DialogSequence emoji={screen.won ? '😭' : stage.trainer.emoji} speaker={stage.trainer.name} lines={screen.won ? (trainerBeaten ? ['Lại thua... Ngươi giỏi thật đấy. Đi đi, đừng để ta thấy mặt.'] : stage.trainer.winText) : stage.trainer.loseText} onDone={() => finishTrainerOutro(screen.won)} />
        </div>,
        `bg-gradient-to-b ${stage.bg}`,
      );
    case 'shop':
      return wrap(
        <ShopScreen
          items={stage.shop} money={game.money} inventory={game.inventory}
          onBuy={(id) => update((g) => g.money >= ITEMS[id].price ? { ...g, money: g.money - ITEMS[id].price, inventory: { ...g.inventory, [id]: (g.inventory[id] ?? 0) + 1 } } : g)}
          onSell={(id) => update((g) => (g.inventory[id] ?? 0) > 0 ? { ...g, money: g.money + Math.floor(ITEMS[id].price / 2), inventory: { ...g.inventory, [id]: (g.inventory[id] ?? 0) - 1 } } : g)}
          onBack={() => setScreen({ k: 'hub' })}
        />,
      );
    case 'party':
      return wrap(<PartyScreen party={game.party} box={game.box} onChange={(party, box) => update((g) => ({ ...g, party, box }))} onBack={() => setScreen({ k: 'hub' })} />);
    case 'dex':
      return wrap(<DexScreen seen={game.seen} caught={game.caught} onBack={() => setScreen({ k: 'hub' })} />);
    case 'center':
      return wrap(
        <div className="max-w-2xl mx-auto mt-10 flex flex-col items-center gap-4">
          <div className="text-8xl anim-float">👩‍⚕️</div>
          <DialogBox speaker="Y tá Que Bông" text={pick(NURSE_LINES)} onNext={() => setScreen({ k: 'hub' })} />
          <div className="flex gap-2">{game.party.map((m) => <div key={m.uid} className="anim-bob"><span className="text-2xl">💚</span></div>)}</div>
        </div>,
        'bg-gradient-to-b from-pink-200 to-rose-300',
      );
    case 'message':
      return wrap(
        <div className="max-w-2xl mx-auto mt-16">
          <DialogBox speaker={screen.speaker} text={screen.text} onNext={() => setScreen({ k: 'hub' })} />
        </div>,
        `bg-gradient-to-b ${stage.bg}`,
      );
    case 'ending':
      return <EndingScreen name={game.name} party={game.party} playtimeBattles={game.battles} onContinue={() => setScreen({ k: 'hub' })} />;
    default:
      return wrap(<div>???</div>);
  }
}
